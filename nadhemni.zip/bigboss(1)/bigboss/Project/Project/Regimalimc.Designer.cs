﻿namespace Project
{
    partial class Regimalimc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Regimalimc));
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.bunifu = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.nom11 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.alim4 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.alim3 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuFlatButton3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.alim2 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.alim1 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.bunifubutton = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.nom1 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuFlatButton2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton4 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuMetroTextbox5 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.bunifuCustomLabel2);
            this.panel1.Controls.Add(this.bunifuMetroTextbox5);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.bunifuFlatButton3);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.bunifuFlatButton2);
            this.panel1.Controls.Add(this.bunifuFlatButton4);
            this.panel1.Location = new System.Drawing.Point(2, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 450);
            this.panel1.TabIndex = 1;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.bunifu);
            this.groupBox4.Controls.Add(this.nom11);
            this.groupBox4.Location = new System.Drawing.Point(402, 301);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(346, 105);
            this.groupBox4.TabIndex = 49;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Enfant";
            // 
            // bunifu
            // 
            this.bunifu.BorderColorFocused = System.Drawing.Color.Blue;
            this.bunifu.BorderColorIdle = System.Drawing.Color.Silver;
            this.bunifu.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.bunifu.BorderThickness = 3;
            this.bunifu.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifu.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.bunifu.ForeColor = System.Drawing.Color.Gray;
            this.bunifu.isPassword = false;
            this.bunifu.Location = new System.Drawing.Point(7, 57);
            this.bunifu.Margin = new System.Windows.Forms.Padding(4);
            this.bunifu.Name = "bunifu";
            this.bunifu.Size = new System.Drawing.Size(252, 29);
            this.bunifu.TabIndex = 47;
            this.bunifu.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // nom11
            // 
            this.nom11.BorderColorFocused = System.Drawing.Color.Blue;
            this.nom11.BorderColorIdle = System.Drawing.Color.Silver;
            this.nom11.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.nom11.BorderThickness = 3;
            this.nom11.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.nom11.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.nom11.ForeColor = System.Drawing.Color.Gray;
            this.nom11.isPassword = false;
            this.nom11.Location = new System.Drawing.Point(7, 20);
            this.nom11.Margin = new System.Windows.Forms.Padding(4);
            this.nom11.Name = "nom11";
            this.nom11.Size = new System.Drawing.Size(252, 29);
            this.nom11.TabIndex = 48;
            this.nom11.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.alim4);
            this.groupBox3.Controls.Add(this.alim3);
            this.groupBox3.Location = new System.Drawing.Point(52, 301);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(301, 105);
            this.groupBox3.TabIndex = 50;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Aliment:";
            // 
            // alim4
            // 
            this.alim4.BorderColorFocused = System.Drawing.Color.Blue;
            this.alim4.BorderColorIdle = System.Drawing.Color.Silver;
            this.alim4.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.alim4.BorderThickness = 3;
            this.alim4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.alim4.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.alim4.ForeColor = System.Drawing.Color.Gray;
            this.alim4.isPassword = false;
            this.alim4.Location = new System.Drawing.Point(12, 56);
            this.alim4.Margin = new System.Windows.Forms.Padding(4);
            this.alim4.Name = "alim4";
            this.alim4.Size = new System.Drawing.Size(252, 29);
            this.alim4.TabIndex = 44;
            this.alim4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // alim3
            // 
            this.alim3.BorderColorFocused = System.Drawing.Color.Blue;
            this.alim3.BorderColorIdle = System.Drawing.Color.Silver;
            this.alim3.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.alim3.BorderThickness = 3;
            this.alim3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.alim3.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.alim3.ForeColor = System.Drawing.Color.Gray;
            this.alim3.isPassword = false;
            this.alim3.Location = new System.Drawing.Point(12, 20);
            this.alim3.Margin = new System.Windows.Forms.Padding(4);
            this.alim3.Name = "alim3";
            this.alim3.Size = new System.Drawing.Size(252, 29);
            this.alim3.TabIndex = 43;
            this.alim3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuFlatButton3
            // 
            this.bunifuFlatButton3.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton3.BackColor = System.Drawing.Color.White;
            this.bunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton3.BorderRadius = 7;
            this.bunifuFlatButton3.ButtonText = "Les aliments apprécis :";
            this.bunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton3.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton3.ForeColor = System.Drawing.Color.White;
            this.bunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton3.Iconimage")));
            this.bunifuFlatButton3.Iconimage_right = null;
            this.bunifuFlatButton3.Iconimage_right_Selected = null;
            this.bunifuFlatButton3.Iconimage_Selected = null;
            this.bunifuFlatButton3.IconMarginLeft = 0;
            this.bunifuFlatButton3.IconMarginRight = 0;
            this.bunifuFlatButton3.IconRightVisible = true;
            this.bunifuFlatButton3.IconRightZoom = 0D;
            this.bunifuFlatButton3.IconVisible = true;
            this.bunifuFlatButton3.IconZoom = 90D;
            this.bunifuFlatButton3.IsTab = false;
            this.bunifuFlatButton3.Location = new System.Drawing.Point(28, 244);
            this.bunifuFlatButton3.Name = "bunifuFlatButton3";
            this.bunifuFlatButton3.Normalcolor = System.Drawing.Color.White;
            this.bunifuFlatButton3.OnHovercolor = System.Drawing.Color.White;
            this.bunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton3.selected = false;
            this.bunifuFlatButton3.Size = new System.Drawing.Size(292, 51);
            this.bunifuFlatButton3.TabIndex = 49;
            this.bunifuFlatButton3.Text = "Les aliments apprécis :";
            this.bunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton3.Textcolor = System.Drawing.Color.Maroon;
            this.bunifuFlatButton3.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.alim2);
            this.groupBox1.Controls.Add(this.alim1);
            this.groupBox1.Location = new System.Drawing.Point(52, 122);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(301, 105);
            this.groupBox1.TabIndex = 49;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Aliment";
            // 
            // alim2
            // 
            this.alim2.BorderColorFocused = System.Drawing.Color.Blue;
            this.alim2.BorderColorIdle = System.Drawing.Color.Silver;
            this.alim2.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.alim2.BorderThickness = 3;
            this.alim2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.alim2.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.alim2.ForeColor = System.Drawing.Color.Gray;
            this.alim2.isPassword = false;
            this.alim2.Location = new System.Drawing.Point(7, 57);
            this.alim2.Margin = new System.Windows.Forms.Padding(4);
            this.alim2.Name = "alim2";
            this.alim2.Size = new System.Drawing.Size(252, 29);
            this.alim2.TabIndex = 44;
            this.alim2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // alim1
            // 
            this.alim1.BorderColorFocused = System.Drawing.Color.Blue;
            this.alim1.BorderColorIdle = System.Drawing.Color.Silver;
            this.alim1.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.alim1.BorderThickness = 3;
            this.alim1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.alim1.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.alim1.ForeColor = System.Drawing.Color.Gray;
            this.alim1.isPassword = false;
            this.alim1.Location = new System.Drawing.Point(12, 20);
            this.alim1.Margin = new System.Windows.Forms.Padding(4);
            this.alim1.Name = "alim1";
            this.alim1.Size = new System.Drawing.Size(252, 29);
            this.alim1.TabIndex = 43;
            this.alim1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.bunifubutton);
            this.groupBox2.Controls.Add(this.nom1);
            this.groupBox2.Location = new System.Drawing.Point(395, 122);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(346, 105);
            this.groupBox2.TabIndex = 48;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Enfant";
            // 
            // bunifubutton
            // 
            this.bunifubutton.BorderColorFocused = System.Drawing.Color.Blue;
            this.bunifubutton.BorderColorIdle = System.Drawing.Color.Silver;
            this.bunifubutton.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.bunifubutton.BorderThickness = 3;
            this.bunifubutton.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifubutton.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.bunifubutton.ForeColor = System.Drawing.Color.Gray;
            this.bunifubutton.isPassword = false;
            this.bunifubutton.Location = new System.Drawing.Point(7, 57);
            this.bunifubutton.Margin = new System.Windows.Forms.Padding(4);
            this.bunifubutton.Name = "bunifubutton";
            this.bunifubutton.Size = new System.Drawing.Size(252, 29);
            this.bunifubutton.TabIndex = 47;
            this.bunifubutton.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // nom1
            // 
            this.nom1.BorderColorFocused = System.Drawing.Color.Blue;
            this.nom1.BorderColorIdle = System.Drawing.Color.Silver;
            this.nom1.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.nom1.BorderThickness = 3;
            this.nom1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.nom1.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.nom1.ForeColor = System.Drawing.Color.Gray;
            this.nom1.isPassword = false;
            this.nom1.Location = new System.Drawing.Point(7, 20);
            this.nom1.Margin = new System.Windows.Forms.Padding(4);
            this.nom1.Name = "nom1";
            this.nom1.Size = new System.Drawing.Size(252, 29);
            this.nom1.TabIndex = 48;
            this.nom1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuFlatButton2
            // 
            this.bunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton2.BackColor = System.Drawing.Color.White;
            this.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton2.BorderRadius = 7;
            this.bunifuFlatButton2.ButtonText = "Les aliments interdits :";
            this.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton2.ForeColor = System.Drawing.Color.White;
            this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton2.Iconimage")));
            this.bunifuFlatButton2.Iconimage_right = null;
            this.bunifuFlatButton2.Iconimage_right_Selected = null;
            this.bunifuFlatButton2.Iconimage_Selected = null;
            this.bunifuFlatButton2.IconMarginLeft = 0;
            this.bunifuFlatButton2.IconMarginRight = 0;
            this.bunifuFlatButton2.IconRightVisible = true;
            this.bunifuFlatButton2.IconRightZoom = 0D;
            this.bunifuFlatButton2.IconVisible = true;
            this.bunifuFlatButton2.IconZoom = 90D;
            this.bunifuFlatButton2.IsTab = false;
            this.bunifuFlatButton2.Location = new System.Drawing.Point(26, 60);
            this.bunifuFlatButton2.Name = "bunifuFlatButton2";
            this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.White;
            this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.White;
            this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton2.selected = false;
            this.bunifuFlatButton2.Size = new System.Drawing.Size(308, 45);
            this.bunifuFlatButton2.TabIndex = 46;
            this.bunifuFlatButton2.Text = "Les aliments interdits :";
            this.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton2.Textcolor = System.Drawing.Color.Maroon;
            this.bunifuFlatButton2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton4
            // 
            this.bunifuFlatButton4.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton4.BackColor = System.Drawing.Color.White;
            this.bunifuFlatButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton4.BorderRadius = 7;
            this.bunifuFlatButton4.ButtonText = "Regime Alimentaire :";
            this.bunifuFlatButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton4.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton4.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton4.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton4.Iconimage")));
            this.bunifuFlatButton4.Iconimage_right = null;
            this.bunifuFlatButton4.Iconimage_right_Selected = null;
            this.bunifuFlatButton4.Iconimage_Selected = null;
            this.bunifuFlatButton4.IconMarginLeft = 0;
            this.bunifuFlatButton4.IconMarginRight = 0;
            this.bunifuFlatButton4.IconRightVisible = true;
            this.bunifuFlatButton4.IconRightZoom = 0D;
            this.bunifuFlatButton4.IconVisible = true;
            this.bunifuFlatButton4.IconZoom = 90D;
            this.bunifuFlatButton4.IsTab = false;
            this.bunifuFlatButton4.Location = new System.Drawing.Point(12, 12);
            this.bunifuFlatButton4.Name = "bunifuFlatButton4";
            this.bunifuFlatButton4.Normalcolor = System.Drawing.Color.White;
            this.bunifuFlatButton4.OnHovercolor = System.Drawing.Color.White;
            this.bunifuFlatButton4.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton4.selected = false;
            this.bunifuFlatButton4.Size = new System.Drawing.Size(308, 31);
            this.bunifuFlatButton4.TabIndex = 45;
            this.bunifuFlatButton4.Text = "Regime Alimentaire :";
            this.bunifuFlatButton4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton4.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton4.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(392, 49);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(36, 13);
            this.bunifuCustomLabel2.TabIndex = 55;
            this.bunifuCustomLabel2.Text = "Durée";
            // 
            // bunifuMetroTextbox5
            // 
            this.bunifuMetroTextbox5.BorderColorFocused = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox5.BorderColorIdle = System.Drawing.Color.Silver;
            this.bunifuMetroTextbox5.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox5.BorderThickness = 3;
            this.bunifuMetroTextbox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMetroTextbox5.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.bunifuMetroTextbox5.ForeColor = System.Drawing.Color.Gray;
            this.bunifuMetroTextbox5.isPassword = false;
            this.bunifuMetroTextbox5.Location = new System.Drawing.Point(449, 33);
            this.bunifuMetroTextbox5.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMetroTextbox5.Name = "bunifuMetroTextbox5";
            this.bunifuMetroTextbox5.Size = new System.Drawing.Size(212, 29);
            this.bunifuMetroTextbox5.TabIndex = 54;
            this.bunifuMetroTextbox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Regimalimc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "Regimalimc";
            this.Text = "Regimalimc";
            this.Load += new System.EventHandler(this.Regimalimc_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox4;
        private Bunifu.Framework.UI.BunifuMetroTextbox bunifu;
        private Bunifu.Framework.UI.BunifuMetroTextbox nom11;
        private System.Windows.Forms.GroupBox groupBox3;
        private Bunifu.Framework.UI.BunifuMetroTextbox alim4;
        private Bunifu.Framework.UI.BunifuMetroTextbox alim3;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton3;
        private System.Windows.Forms.GroupBox groupBox1;
        private Bunifu.Framework.UI.BunifuMetroTextbox alim2;
        private Bunifu.Framework.UI.BunifuMetroTextbox alim1;
        private System.Windows.Forms.GroupBox groupBox2;
        private Bunifu.Framework.UI.BunifuMetroTextbox bunifubutton;
        private Bunifu.Framework.UI.BunifuMetroTextbox nom1;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton2;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuMetroTextbox bunifuMetroTextbox5;
    }
}