﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Les_Factures : Form
    {
        public Les_Factures()
        {
            InitializeComponent();
        }

        private void Les_Factures_Load(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            try
            {

                facture f = new facture();
                f.id_facture = yourself.ch;
                f.eau = double.Parse(txt_eau.Text);
                f.steg = double.Parse(txt_steg.Text);

                f.tel = double.Parse(txt_tel.Text);
                f.date_eau = txt_limite.Value;
                f.date_steg = txt_limite1.Value;
                f.date_tel = txt_limite2.Value;

                yourself.d.facture.InsertOnSubmit(f);

                yourself.d.SubmitChanges();
                MessageBox.Show("facture ajoutée avec succes");
                this.Close();
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }


        }
    }
}
