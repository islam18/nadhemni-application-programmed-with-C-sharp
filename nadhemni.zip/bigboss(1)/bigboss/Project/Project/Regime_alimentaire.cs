﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Regime_alimentaire : Form
    {
        public Regime_alimentaire()
        {
            InitializeComponent();
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {

        }

        private void Regime_alimentaire_Load(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {

            if (metroComboBox1.SelectedItem.ToString().Equals("père"))
            {
                suivi_regime r = new suivi_regime();
                r.id_regime = yourself.ch;
                if (checkBox1.Checked)
                    r.durée = "6mois";
                if (checkBox2.Checked)
                    r.durée = "12mois";
                if (checkBox3.Checked)
                    r.durée = "periode indeterminée";
                r.personne = metroComboBox1.SelectedItem.ToString();


                r.aliment_interdit = metroComboBox4.SelectedItem.ToString();
                r.aliment_apprécis = metroComboBox3.SelectedItem.ToString();
                yourself.d.suivi_regime.InsertOnSubmit(r);
            }
            else
            {
                suivi_regime2 r1 = new suivi_regime2();
                r1.id_regime2 = yourself.ch;
                if (checkBox1.Checked)
                    r1.durée = "6mois";
                if (checkBox2.Checked)
                    r1.durée = "12mois";
                if (checkBox3.Checked)
                    r1.durée = "periode indeterminée";
                r1.personne = metroComboBox1.SelectedItem.ToString();


                r1.aliment_interdit = metroComboBox4.SelectedItem.ToString();
                r1.aliment_apprécis = metroComboBox3.SelectedItem.ToString();
                yourself.d.suivi_regime2s.InsertOnSubmit(r1);
            }



            // Submit the change to the database.
            try
            {
                yourself.d.SubmitChanges();
                MessageBox.Show(" ajouté avec succes");
                this.Close();

            }
            catch (Exception y)
            {
                Console.WriteLine(y);
            }
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {

        }

        private void metroComboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void metroComboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void bunifuCustomLabel2_Click(object sender, EventArgs e)
        {

        }

        private void metroComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {

        }
    }
}