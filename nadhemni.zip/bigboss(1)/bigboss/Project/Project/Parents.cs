﻿using projet;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Parents : Form
    {
        public Parents()
        {
            InitializeComponent();
        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {

        }

        private void metroComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void m5_CheckedChanged(object sender, EventArgs e)
        {
            if (m5.Checked)
            {
                Regime_alimentaire regime_Alimentair = new Regime_alimentaire();
                regime_Alimentair.ShowDialog();
            }
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            Medocs m = new Medocs();
            m.ShowDialog();
        }

        private void bunifuFlatButton6_Click(object sender, EventArgs e)
        {
            parent p = new parent();
            p.id_parent = yourself.ch;
            p.id_regime_parent = yourself.ch;
            p.id_medicament_parent = yourself.ch;
            p.id_rdv_parent = yourself.ch;
            if (bunifuCheckbox1.Checked)
                p.hebergement = 1;
            else
                p.hebergement = 0;
            if (bunifuCheckbox5.Checked)
                p.medic = 1;
            else
                p.medic = 0;
            if (bunifuCheckbox2.Checked)
                p.Rdv_med = 1;
            else
                p.Rdv_med = 0;
            if (m5.Checked)

                p.Reg_alim = 1;
            else
                p.Reg_alim = 0;

            if (bunifuCheckbox7.Checked)
                p.Etat = "autonome";
            else
                p.Etat = "inactif";

           
            try
            {
                yourself.d.parents.InsertOnSubmit(p);
                yourself.d.SubmitChanges();
                
                MessageBox.Show(" ajouté avec succes");


            }
            catch (Exception y)
            {
                Console.WriteLine(y);
            }


        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void bunifuGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuCustomLabel2_Click(object sender, EventArgs e)
        {

        }

        private void m5_OnChange(object sender, EventArgs e)
        {
            if (m5.Checked)
            {
                Regime_alimentaire regime_Alimentair = new Regime_alimentaire();
                regime_Alimentair.ShowDialog();
            }
        }

        private void bunifuCheckbox2_OnChange(object sender, EventArgs e)
        {
            if (bunifuCheckbox2.Checked)
            {
                Medocs m = new Medocs();
                m.ShowDialog();
            }
        }

        private void bunifuCheckbox5_OnChange(object sender, EventArgs e)
        {
            if (bunifuCheckbox5.Checked)
            {
                rendez_vous v = new rendez_vous();
                v.ShowDialog();

            }
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            parent p = new parent();
            p.id_parent = yourself.ch;
            p.id_regime_parent = yourself.ch;
            p.id_medicament_parent = yourself.ch;
            p.id_rdv_parent = yourself.ch;
            if (bunifuCheckbox1.Checked)
                p.hebergement = 1;
            else
                p.hebergement = 0;
            if (bunifuCheckbox5.Checked)
                p.medic = 1;
            else
                p.medic = 0;
            if (bunifuCheckbox2.Checked)
                p.Rdv_med = 1;
            else
                p.Rdv_med = 0;
            if (m5.Checked)

                p.Reg_alim = 1;
            else
                p.Reg_alim = 0;

            if (bunifuCheckbox7.Checked)
                p.Etat = "autonome";
            else
                p.Etat = "inactif";


            try
            {
                yourself.d.parents.InsertOnSubmit(p);
                yourself.d.SubmitChanges();

                MessageBox.Show(" ajouté avec succes");


            }
            catch (Exception y)
            {
                Console.WriteLine(y);
            }

        }
    }
}
