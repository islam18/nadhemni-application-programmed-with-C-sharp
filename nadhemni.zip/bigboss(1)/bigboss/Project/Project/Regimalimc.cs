﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Regimalimc : Form
    {
        public Regimalimc()
        {
            InitializeComponent();
        }

        private void Regimalimc_Load(object sender, EventArgs e)
        {
            suivi_regime1 f = (from u in yourself.d.suivi_regime1
                              where u.id_regime1
                              .Equals(inscri.s)
                              select u).FirstOrDefault();
            if (f != null)
            {
                nom1.Text = f.personne.ToString();
                bunifuMetroTextbox5.Text = f.durée.ToString();
                alim1.Text = f.aliment_interdit.ToString();
                alim3.Text = f.aliment_apprécis.ToString();
                nom11.Text = f.personne.ToString();
            }
            else
                MessageBox.Show("pas de regime pour les enfants");
           
        }
    }
}
