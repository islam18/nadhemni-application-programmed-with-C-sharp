﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class MyWork : MetroFramework.Forms.MetroForm
    {
        travail t = new travail();
       
         

        public MyWork()
        {
            InitializeComponent();
        }

        private void MyWork_Load(object sender, EventArgs e)
        {
            travail f = (from u in yourself.d.travail
                         where u.id_travail.Equals(inscri.s)
                         select u).FirstOrDefault();
            if (f != null)

            {
                debut.Text = f.début.ToString();
                fin.Text = f.fin.ToString();
                reunion.Text = "Mercredi";//t.reunion.ToString();
                                          // todo.Text = t.to_do.ToString();}
            }
        }
        private void debut_TextChanged(object sender, EventArgs e)
        {

        }

        private void fin_TextChanged(object sender, EventArgs e)
        {

        }

        private void reunion_TextChanged(object sender, EventArgs e)
        {

        }

        private void todo_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
         
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
