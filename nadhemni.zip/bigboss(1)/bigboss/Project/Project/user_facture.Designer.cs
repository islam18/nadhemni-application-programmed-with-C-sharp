﻿namespace Project
{
    partial class user_facture
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.t1 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.date_eau = new MetroFramework.Controls.MetroDateTime();
            this.date_steg = new MetroFramework.Controls.MetroDateTime();
            this.date_tel = new MetroFramework.Controls.MetroDateTime();
            this.bunifuFlatButton7 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton5 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.eau1 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.steg1 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.tel1 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.eau = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.steg = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.tel = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuFlatButton3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton4 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton6 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.notifications = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuMetroTextbox1 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuMetroTextbox2 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuMetroTextbox3 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.Controls.Add(this.bunifuMetroTextbox3);
            this.panel1.Controls.Add(this.bunifuMetroTextbox2);
            this.panel1.Controls.Add(this.bunifuMetroTextbox1);
            this.panel1.Controls.Add(this.t1);
            this.panel1.Controls.Add(this.date_eau);
            this.panel1.Controls.Add(this.date_steg);
            this.panel1.Controls.Add(this.date_tel);
            this.panel1.Controls.Add(this.bunifuFlatButton7);
            this.panel1.Controls.Add(this.bunifuFlatButton5);
            this.panel1.Controls.Add(this.bunifuFlatButton2);
            this.panel1.Controls.Add(this.eau1);
            this.panel1.Controls.Add(this.steg1);
            this.panel1.Controls.Add(this.tel1);
            this.panel1.Controls.Add(this.eau);
            this.panel1.Controls.Add(this.steg);
            this.panel1.Controls.Add(this.tel);
            this.panel1.Controls.Add(this.bunifuFlatButton3);
            this.panel1.Controls.Add(this.bunifuFlatButton4);
            this.panel1.Controls.Add(this.bunifuFlatButton6);
            this.panel1.Controls.Add(this.bunifuFlatButton1);
            this.panel1.Controls.Add(this.notifications);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(801, 576);
            this.panel1.TabIndex = 0;
            // 
            // t1
            // 
            this.t1.BorderColorFocused = System.Drawing.Color.Blue;
            this.t1.BorderColorIdle = System.Drawing.Color.Silver;
            this.t1.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.t1.BorderThickness = 3;
            this.t1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.t1.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.t1.ForeColor = System.Drawing.Color.Gray;
            this.t1.isPassword = false;
            this.t1.Location = new System.Drawing.Point(461, 13);
            this.t1.Margin = new System.Windows.Forms.Padding(4);
            this.t1.Name = "t1";
            this.t1.Size = new System.Drawing.Size(115, 37);
            this.t1.TabIndex = 59;
            this.t1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // date_eau
            // 
            this.date_eau.Location = new System.Drawing.Point(481, 73);
            this.date_eau.MinimumSize = new System.Drawing.Size(0, 29);
            this.date_eau.Name = "date_eau";
            this.date_eau.Size = new System.Drawing.Size(183, 29);
            this.date_eau.TabIndex = 58;
            // 
            // date_steg
            // 
            this.date_steg.Location = new System.Drawing.Point(481, 137);
            this.date_steg.MinimumSize = new System.Drawing.Size(0, 29);
            this.date_steg.Name = "date_steg";
            this.date_steg.Size = new System.Drawing.Size(183, 29);
            this.date_steg.TabIndex = 57;
            // 
            // date_tel
            // 
            this.date_tel.Location = new System.Drawing.Point(481, 196);
            this.date_tel.MinimumSize = new System.Drawing.Size(0, 29);
            this.date_tel.Name = "date_tel";
            this.date_tel.Size = new System.Drawing.Size(189, 29);
            this.date_tel.TabIndex = 56;
            // 
            // bunifuFlatButton7
            // 
            this.bunifuFlatButton7.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton7.BorderRadius = 7;
            this.bunifuFlatButton7.ButtonText = "Telephone/Internet";
            this.bunifuFlatButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton7.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton7.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton7.Iconimage = null;
            this.bunifuFlatButton7.Iconimage_right = null;
            this.bunifuFlatButton7.Iconimage_right_Selected = null;
            this.bunifuFlatButton7.Iconimage_Selected = null;
            this.bunifuFlatButton7.IconMarginLeft = 0;
            this.bunifuFlatButton7.IconMarginRight = 0;
            this.bunifuFlatButton7.IconRightVisible = true;
            this.bunifuFlatButton7.IconRightZoom = 0D;
            this.bunifuFlatButton7.IconVisible = true;
            this.bunifuFlatButton7.IconZoom = 90D;
            this.bunifuFlatButton7.IsTab = false;
            this.bunifuFlatButton7.Location = new System.Drawing.Point(29, 505);
            this.bunifuFlatButton7.Name = "bunifuFlatButton7";
            this.bunifuFlatButton7.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton7.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton7.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton7.selected = false;
            this.bunifuFlatButton7.Size = new System.Drawing.Size(169, 38);
            this.bunifuFlatButton7.TabIndex = 51;
            this.bunifuFlatButton7.Text = "Telephone/Internet";
            this.bunifuFlatButton7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton7.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton7.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton5
            // 
            this.bunifuFlatButton5.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton5.BorderRadius = 7;
            this.bunifuFlatButton5.ButtonText = "STEG";
            this.bunifuFlatButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton5.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton5.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton5.Iconimage = null;
            this.bunifuFlatButton5.Iconimage_right = null;
            this.bunifuFlatButton5.Iconimage_right_Selected = null;
            this.bunifuFlatButton5.Iconimage_Selected = null;
            this.bunifuFlatButton5.IconMarginLeft = 0;
            this.bunifuFlatButton5.IconMarginRight = 0;
            this.bunifuFlatButton5.IconRightVisible = true;
            this.bunifuFlatButton5.IconRightZoom = 0D;
            this.bunifuFlatButton5.IconVisible = true;
            this.bunifuFlatButton5.IconZoom = 90D;
            this.bunifuFlatButton5.IsTab = false;
            this.bunifuFlatButton5.Location = new System.Drawing.Point(29, 450);
            this.bunifuFlatButton5.Name = "bunifuFlatButton5";
            this.bunifuFlatButton5.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton5.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton5.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton5.selected = false;
            this.bunifuFlatButton5.Size = new System.Drawing.Size(169, 38);
            this.bunifuFlatButton5.TabIndex = 50;
            this.bunifuFlatButton5.Text = "STEG";
            this.bunifuFlatButton5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton5.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton5.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton2
            // 
            this.bunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton2.BorderRadius = 7;
            this.bunifuFlatButton2.ButtonText = "Eau";
            this.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconimage = null;
            this.bunifuFlatButton2.Iconimage_right = null;
            this.bunifuFlatButton2.Iconimage_right_Selected = null;
            this.bunifuFlatButton2.Iconimage_Selected = null;
            this.bunifuFlatButton2.IconMarginLeft = 0;
            this.bunifuFlatButton2.IconMarginRight = 0;
            this.bunifuFlatButton2.IconRightVisible = true;
            this.bunifuFlatButton2.IconRightZoom = 0D;
            this.bunifuFlatButton2.IconVisible = true;
            this.bunifuFlatButton2.IconZoom = 90D;
            this.bunifuFlatButton2.IsTab = false;
            this.bunifuFlatButton2.Location = new System.Drawing.Point(29, 387);
            this.bunifuFlatButton2.Name = "bunifuFlatButton2";
            this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton2.selected = false;
            this.bunifuFlatButton2.Size = new System.Drawing.Size(169, 38);
            this.bunifuFlatButton2.TabIndex = 49;
            this.bunifuFlatButton2.Text = "Eau";
            this.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton2.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // eau1
            // 
            this.eau1.BorderColorFocused = System.Drawing.Color.Blue;
            this.eau1.BorderColorIdle = System.Drawing.Color.Silver;
            this.eau1.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.eau1.BorderThickness = 3;
            this.eau1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.eau1.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.eau1.ForeColor = System.Drawing.Color.Gray;
            this.eau1.isPassword = false;
            this.eau1.Location = new System.Drawing.Point(235, 387);
            this.eau1.Margin = new System.Windows.Forms.Padding(4);
            this.eau1.Name = "eau1";
            this.eau1.Size = new System.Drawing.Size(209, 37);
            this.eau1.TabIndex = 48;
            this.eau1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.eau1.OnValueChanged += new System.EventHandler(this.eau1_OnValueChanged);
            // 
            // steg1
            // 
            this.steg1.BorderColorFocused = System.Drawing.Color.Blue;
            this.steg1.BorderColorIdle = System.Drawing.Color.Silver;
            this.steg1.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.steg1.BorderThickness = 3;
            this.steg1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.steg1.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.steg1.ForeColor = System.Drawing.Color.Gray;
            this.steg1.isPassword = false;
            this.steg1.Location = new System.Drawing.Point(235, 450);
            this.steg1.Margin = new System.Windows.Forms.Padding(4);
            this.steg1.Name = "steg1";
            this.steg1.Size = new System.Drawing.Size(209, 37);
            this.steg1.TabIndex = 47;
            this.steg1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // tel1
            // 
            this.tel1.BorderColorFocused = System.Drawing.Color.Blue;
            this.tel1.BorderColorIdle = System.Drawing.Color.Silver;
            this.tel1.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.tel1.BorderThickness = 3;
            this.tel1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tel1.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.tel1.ForeColor = System.Drawing.Color.Gray;
            this.tel1.isPassword = false;
            this.tel1.Location = new System.Drawing.Point(235, 505);
            this.tel1.Margin = new System.Windows.Forms.Padding(4);
            this.tel1.Name = "tel1";
            this.tel1.Size = new System.Drawing.Size(209, 37);
            this.tel1.TabIndex = 46;
            this.tel1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tel1.OnValueChanged += new System.EventHandler(this.bunifuMetroTextbox3_OnValueChanged);
            // 
            // eau
            // 
            this.eau.BorderColorFocused = System.Drawing.Color.Blue;
            this.eau.BorderColorIdle = System.Drawing.Color.Silver;
            this.eau.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.eau.BorderThickness = 3;
            this.eau.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.eau.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.eau.ForeColor = System.Drawing.Color.Gray;
            this.eau.isPassword = false;
            this.eau.Location = new System.Drawing.Point(235, 73);
            this.eau.Margin = new System.Windows.Forms.Padding(4);
            this.eau.Name = "eau";
            this.eau.Size = new System.Drawing.Size(209, 37);
            this.eau.TabIndex = 45;
            this.eau.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // steg
            // 
            this.steg.BorderColorFocused = System.Drawing.Color.Blue;
            this.steg.BorderColorIdle = System.Drawing.Color.Silver;
            this.steg.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.steg.BorderThickness = 3;
            this.steg.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.steg.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.steg.ForeColor = System.Drawing.Color.Gray;
            this.steg.isPassword = false;
            this.steg.Location = new System.Drawing.Point(235, 137);
            this.steg.Margin = new System.Windows.Forms.Padding(4);
            this.steg.Name = "steg";
            this.steg.Size = new System.Drawing.Size(209, 37);
            this.steg.TabIndex = 44;
            this.steg.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // tel
            // 
            this.tel.BorderColorFocused = System.Drawing.Color.Blue;
            this.tel.BorderColorIdle = System.Drawing.Color.Silver;
            this.tel.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.tel.BorderThickness = 3;
            this.tel.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tel.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.tel.ForeColor = System.Drawing.Color.Gray;
            this.tel.isPassword = false;
            this.tel.Location = new System.Drawing.Point(235, 196);
            this.tel.Margin = new System.Windows.Forms.Padding(4);
            this.tel.Name = "tel";
            this.tel.Size = new System.Drawing.Size(209, 37);
            this.tel.TabIndex = 43;
            this.tel.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tel.OnValueChanged += new System.EventHandler(this.txt_dep_OnValueChanged);
            // 
            // bunifuFlatButton3
            // 
            this.bunifuFlatButton3.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton3.BorderRadius = 7;
            this.bunifuFlatButton3.ButtonText = "Telephone/Internet";
            this.bunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton3.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.Iconimage = null;
            this.bunifuFlatButton3.Iconimage_right = null;
            this.bunifuFlatButton3.Iconimage_right_Selected = null;
            this.bunifuFlatButton3.Iconimage_Selected = null;
            this.bunifuFlatButton3.IconMarginLeft = 0;
            this.bunifuFlatButton3.IconMarginRight = 0;
            this.bunifuFlatButton3.IconRightVisible = true;
            this.bunifuFlatButton3.IconRightZoom = 0D;
            this.bunifuFlatButton3.IconVisible = true;
            this.bunifuFlatButton3.IconZoom = 90D;
            this.bunifuFlatButton3.IsTab = false;
            this.bunifuFlatButton3.Location = new System.Drawing.Point(12, 196);
            this.bunifuFlatButton3.Name = "bunifuFlatButton3";
            this.bunifuFlatButton3.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton3.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton3.selected = false;
            this.bunifuFlatButton3.Size = new System.Drawing.Size(169, 38);
            this.bunifuFlatButton3.TabIndex = 40;
            this.bunifuFlatButton3.Text = "Telephone/Internet";
            this.bunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton3.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton3.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton4
            // 
            this.bunifuFlatButton4.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton4.BorderRadius = 7;
            this.bunifuFlatButton4.ButtonText = "STEG";
            this.bunifuFlatButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton4.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton4.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton4.Iconimage = null;
            this.bunifuFlatButton4.Iconimage_right = null;
            this.bunifuFlatButton4.Iconimage_right_Selected = null;
            this.bunifuFlatButton4.Iconimage_Selected = null;
            this.bunifuFlatButton4.IconMarginLeft = 0;
            this.bunifuFlatButton4.IconMarginRight = 0;
            this.bunifuFlatButton4.IconRightVisible = true;
            this.bunifuFlatButton4.IconRightZoom = 0D;
            this.bunifuFlatButton4.IconVisible = true;
            this.bunifuFlatButton4.IconZoom = 90D;
            this.bunifuFlatButton4.IsTab = false;
            this.bunifuFlatButton4.Location = new System.Drawing.Point(12, 136);
            this.bunifuFlatButton4.Name = "bunifuFlatButton4";
            this.bunifuFlatButton4.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton4.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton4.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton4.selected = false;
            this.bunifuFlatButton4.Size = new System.Drawing.Size(169, 38);
            this.bunifuFlatButton4.TabIndex = 39;
            this.bunifuFlatButton4.Text = "STEG";
            this.bunifuFlatButton4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton4.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton4.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton6
            // 
            this.bunifuFlatButton6.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton6.BorderRadius = 7;
            this.bunifuFlatButton6.ButtonText = "Eau";
            this.bunifuFlatButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton6.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton6.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton6.Iconimage = null;
            this.bunifuFlatButton6.Iconimage_right = null;
            this.bunifuFlatButton6.Iconimage_right_Selected = null;
            this.bunifuFlatButton6.Iconimage_Selected = null;
            this.bunifuFlatButton6.IconMarginLeft = 0;
            this.bunifuFlatButton6.IconMarginRight = 0;
            this.bunifuFlatButton6.IconRightVisible = true;
            this.bunifuFlatButton6.IconRightZoom = 0D;
            this.bunifuFlatButton6.IconVisible = true;
            this.bunifuFlatButton6.IconZoom = 90D;
            this.bunifuFlatButton6.IsTab = false;
            this.bunifuFlatButton6.Location = new System.Drawing.Point(12, 72);
            this.bunifuFlatButton6.Name = "bunifuFlatButton6";
            this.bunifuFlatButton6.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton6.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton6.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton6.selected = false;
            this.bunifuFlatButton6.Size = new System.Drawing.Size(169, 38);
            this.bunifuFlatButton6.TabIndex = 36;
            this.bunifuFlatButton6.Text = "Eau";
            this.bunifuFlatButton6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton6.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton6.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Les autres factures :";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = global::Project.Properties.Resources.warning;
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(12, 296);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(284, 52);
            this.bunifuFlatButton1.TabIndex = 31;
            this.bunifuFlatButton1.Text = "Les autres factures :";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // notifications
            // 
            this.notifications.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.notifications.BackColor = System.Drawing.Color.White;
            this.notifications.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.notifications.BorderRadius = 0;
            this.notifications.ButtonText = " Les factures que vous devez payer ce mois  :";
            this.notifications.Cursor = System.Windows.Forms.Cursors.Hand;
            this.notifications.DisabledColor = System.Drawing.Color.Gray;
            this.notifications.Iconcolor = System.Drawing.Color.Transparent;
            this.notifications.Iconimage = global::Project.Properties.Resources.bell_icon;
            this.notifications.Iconimage_right = null;
            this.notifications.Iconimage_right_Selected = null;
            this.notifications.Iconimage_Selected = null;
            this.notifications.IconMarginLeft = 0;
            this.notifications.IconMarginRight = 0;
            this.notifications.IconRightVisible = true;
            this.notifications.IconRightZoom = 0D;
            this.notifications.IconVisible = true;
            this.notifications.IconZoom = 90D;
            this.notifications.IsTab = false;
            this.notifications.Location = new System.Drawing.Point(3, 3);
            this.notifications.Name = "notifications";
            this.notifications.Normalcolor = System.Drawing.Color.White;
            this.notifications.OnHovercolor = System.Drawing.Color.White;
            this.notifications.OnHoverTextColor = System.Drawing.Color.White;
            this.notifications.selected = false;
            this.notifications.Size = new System.Drawing.Size(441, 54);
            this.notifications.TabIndex = 30;
            this.notifications.Text = " Les factures que vous devez payer ce mois  :";
            this.notifications.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.notifications.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.notifications.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.notifications.Click += new System.EventHandler(this.bunifuFlatButton2_Click);
            // 
            // bunifuMetroTextbox1
            // 
            this.bunifuMetroTextbox1.BorderColorFocused = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox1.BorderColorIdle = System.Drawing.Color.Silver;
            this.bunifuMetroTextbox1.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox1.BorderThickness = 3;
            this.bunifuMetroTextbox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMetroTextbox1.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.bunifuMetroTextbox1.ForeColor = System.Drawing.Color.Gray;
            this.bunifuMetroTextbox1.isPassword = false;
            this.bunifuMetroTextbox1.Location = new System.Drawing.Point(671, 72);
            this.bunifuMetroTextbox1.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMetroTextbox1.Name = "bunifuMetroTextbox1";
            this.bunifuMetroTextbox1.Size = new System.Drawing.Size(101, 30);
            this.bunifuMetroTextbox1.TabIndex = 60;
            this.bunifuMetroTextbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuMetroTextbox2
            // 
            this.bunifuMetroTextbox2.BorderColorFocused = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox2.BorderColorIdle = System.Drawing.Color.Silver;
            this.bunifuMetroTextbox2.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox2.BorderThickness = 3;
            this.bunifuMetroTextbox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMetroTextbox2.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.bunifuMetroTextbox2.ForeColor = System.Drawing.Color.Gray;
            this.bunifuMetroTextbox2.isPassword = false;
            this.bunifuMetroTextbox2.Location = new System.Drawing.Point(671, 136);
            this.bunifuMetroTextbox2.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMetroTextbox2.Name = "bunifuMetroTextbox2";
            this.bunifuMetroTextbox2.Size = new System.Drawing.Size(101, 30);
            this.bunifuMetroTextbox2.TabIndex = 61;
            this.bunifuMetroTextbox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuMetroTextbox3
            // 
            this.bunifuMetroTextbox3.BorderColorFocused = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox3.BorderColorIdle = System.Drawing.Color.Silver;
            this.bunifuMetroTextbox3.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox3.BorderThickness = 3;
            this.bunifuMetroTextbox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMetroTextbox3.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.bunifuMetroTextbox3.ForeColor = System.Drawing.Color.Gray;
            this.bunifuMetroTextbox3.isPassword = false;
            this.bunifuMetroTextbox3.Location = new System.Drawing.Point(677, 196);
            this.bunifuMetroTextbox3.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMetroTextbox3.Name = "bunifuMetroTextbox3";
            this.bunifuMetroTextbox3.Size = new System.Drawing.Size(101, 30);
            this.bunifuMetroTextbox3.TabIndex = 62;
            this.bunifuMetroTextbox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // user_facture
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 575);
            this.Controls.Add(this.panel1);
            this.Name = "user_facture";
            this.Text = "user_facture";
            this.Load += new System.EventHandler(this.user_facture_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuFlatButton notifications;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton6;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton4;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton3;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton7;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton5;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton2;
        private Bunifu.Framework.UI.BunifuMetroTextbox eau1;
        private Bunifu.Framework.UI.BunifuMetroTextbox steg1;
        private Bunifu.Framework.UI.BunifuMetroTextbox tel1;
        private Bunifu.Framework.UI.BunifuMetroTextbox eau;
        private Bunifu.Framework.UI.BunifuMetroTextbox steg;
        private Bunifu.Framework.UI.BunifuMetroTextbox tel;
        private MetroFramework.Controls.MetroDateTime date_eau;
        private MetroFramework.Controls.MetroDateTime date_steg;
        private MetroFramework.Controls.MetroDateTime date_tel;
        private Bunifu.Framework.UI.BunifuMetroTextbox t1;
        private Bunifu.Framework.UI.BunifuMetroTextbox bunifuMetroTextbox3;
        private Bunifu.Framework.UI.BunifuMetroTextbox bunifuMetroTextbox2;
        private Bunifu.Framework.UI.BunifuMetroTextbox bunifuMetroTextbox1;
    }
}