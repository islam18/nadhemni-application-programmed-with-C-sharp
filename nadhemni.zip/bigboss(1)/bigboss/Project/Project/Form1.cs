﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
         
        }

        private void bunifuFlatButton6_Click(object sender, EventArgs e)
        {

            user_facture f = new user_facture(id.Text);
            f.ShowDialog();
        }

        private void bunifuFlatButton7_Click(object sender, EventArgs e)
        {
            MyWork f = new MyWork();
            f.ShowDialog();

        }

        private void bunifuFlatButton8_Click(object sender, EventArgs e)
        {
            parent_user f = new parent_user();
            f.ShowDialog();
        }

        private void bunifuImageButton4_Click(object sender, EventArgs e)
        {
            yourself f = new yourself();
            f.ShowDialog();

        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            profile f = new profile();
            f.ShowDialog();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            dashbord d = new dashbord();
            d.Show();
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {
            children_user c = new children_user();
            c.ShowDialog();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void id_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            id.Text = inscri.s;
        }
    }
}
