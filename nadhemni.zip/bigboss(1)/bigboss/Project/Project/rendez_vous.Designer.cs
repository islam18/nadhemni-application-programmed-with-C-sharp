﻿namespace Project
{
    partial class rendez_vous
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(rendez_vous));
            this.panel1 = new System.Windows.Forms.Panel();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.notifications = new Bunifu.Framework.UI.BunifuFlatButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.bunifuDatepicker3 = new Bunifu.Framework.UI.BunifuDatepicker();
            this.bunifuDatepicker4 = new Bunifu.Framework.UI.BunifuDatepicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bunifuDatepicker2 = new Bunifu.Framework.UI.BunifuDatepicker();
            this.bunifuDatepicker1 = new Bunifu.Framework.UI.BunifuDatepicker();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.bunifuFlatButton1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.notifications);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Location = new System.Drawing.Point(-1, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(603, 416);
            this.panel1.TabIndex = 0;
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 7;
            this.bunifuFlatButton1.ButtonText = "Valider ";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton1.Iconimage")));
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(397, 334);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(163, 59);
            this.bunifuFlatButton1.TabIndex = 53;
            this.bunifuFlatButton1.Text = "Valider ";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Firebrick;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(616, 10);
            this.panel2.TabIndex = 52;
            // 
            // notifications
            // 
            this.notifications.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.notifications.BackColor = System.Drawing.Color.White;
            this.notifications.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.notifications.BorderRadius = 0;
            this.notifications.ButtonText = " Les rendez_vous  :";
            this.notifications.Cursor = System.Windows.Forms.Cursors.Hand;
            this.notifications.DisabledColor = System.Drawing.Color.Gray;
            this.notifications.Iconcolor = System.Drawing.Color.Transparent;
            this.notifications.Iconimage = global::Project.Properties.Resources.bell_icon;
            this.notifications.Iconimage_right = null;
            this.notifications.Iconimage_right_Selected = null;
            this.notifications.Iconimage_Selected = null;
            this.notifications.IconMarginLeft = 0;
            this.notifications.IconMarginRight = 0;
            this.notifications.IconRightVisible = true;
            this.notifications.IconRightZoom = 0D;
            this.notifications.IconVisible = true;
            this.notifications.IconZoom = 90D;
            this.notifications.IsTab = false;
            this.notifications.Location = new System.Drawing.Point(3, 14);
            this.notifications.Name = "notifications";
            this.notifications.Normalcolor = System.Drawing.Color.White;
            this.notifications.OnHovercolor = System.Drawing.Color.White;
            this.notifications.OnHoverTextColor = System.Drawing.Color.White;
            this.notifications.selected = false;
            this.notifications.Size = new System.Drawing.Size(352, 54);
            this.notifications.TabIndex = 51;
            this.notifications.Text = " Les rendez_vous  :";
            this.notifications.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.notifications.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.notifications.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.bunifuDatepicker3);
            this.groupBox2.Controls.Add(this.bunifuDatepicker4);
            this.groupBox2.Location = new System.Drawing.Point(13, 223);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(285, 91);
            this.groupBox2.TabIndex = 45;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Le Pére :";
            // 
            // bunifuDatepicker3
            // 
            this.bunifuDatepicker3.BackColor = System.Drawing.Color.Firebrick;
            this.bunifuDatepicker3.BorderRadius = 0;
            this.bunifuDatepicker3.ForeColor = System.Drawing.Color.White;
            this.bunifuDatepicker3.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.bunifuDatepicker3.FormatCustom = null;
            this.bunifuDatepicker3.Location = new System.Drawing.Point(12, 49);
            this.bunifuDatepicker3.Name = "bunifuDatepicker3";
            this.bunifuDatepicker3.Size = new System.Drawing.Size(244, 24);
            this.bunifuDatepicker3.TabIndex = 49;
            this.bunifuDatepicker3.Value = new System.DateTime(2020, 5, 1, 23, 44, 14, 973);
            // 
            // bunifuDatepicker4
            // 
            this.bunifuDatepicker4.BackColor = System.Drawing.Color.Firebrick;
            this.bunifuDatepicker4.BorderRadius = 0;
            this.bunifuDatepicker4.ForeColor = System.Drawing.Color.White;
            this.bunifuDatepicker4.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.bunifuDatepicker4.FormatCustom = null;
            this.bunifuDatepicker4.Location = new System.Drawing.Point(12, 19);
            this.bunifuDatepicker4.Name = "bunifuDatepicker4";
            this.bunifuDatepicker4.Size = new System.Drawing.Size(244, 24);
            this.bunifuDatepicker4.TabIndex = 50;
            this.bunifuDatepicker4.Value = new System.DateTime(2020, 5, 1, 23, 44, 14, 973);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bunifuDatepicker2);
            this.groupBox1.Controls.Add(this.bunifuDatepicker1);
            this.groupBox1.Location = new System.Drawing.Point(13, 103);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(272, 97);
            this.groupBox1.TabIndex = 35;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "La Mére :";
            // 
            // bunifuDatepicker2
            // 
            this.bunifuDatepicker2.BackColor = System.Drawing.Color.Firebrick;
            this.bunifuDatepicker2.BorderRadius = 0;
            this.bunifuDatepicker2.ForeColor = System.Drawing.Color.White;
            this.bunifuDatepicker2.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.bunifuDatepicker2.FormatCustom = null;
            this.bunifuDatepicker2.Location = new System.Drawing.Point(12, 64);
            this.bunifuDatepicker2.Name = "bunifuDatepicker2";
            this.bunifuDatepicker2.Size = new System.Drawing.Size(244, 24);
            this.bunifuDatepicker2.TabIndex = 48;
            this.bunifuDatepicker2.Value = new System.DateTime(2020, 5, 1, 23, 44, 14, 973);
            // 
            // bunifuDatepicker1
            // 
            this.bunifuDatepicker1.BackColor = System.Drawing.Color.Firebrick;
            this.bunifuDatepicker1.BorderRadius = 0;
            this.bunifuDatepicker1.ForeColor = System.Drawing.Color.White;
            this.bunifuDatepicker1.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.bunifuDatepicker1.FormatCustom = null;
            this.bunifuDatepicker1.Location = new System.Drawing.Point(12, 34);
            this.bunifuDatepicker1.Name = "bunifuDatepicker1";
            this.bunifuDatepicker1.Size = new System.Drawing.Size(244, 24);
            this.bunifuDatepicker1.TabIndex = 47;
            this.bunifuDatepicker1.Value = new System.DateTime(2020, 5, 1, 23, 44, 14, 973);
            // 
            // rendez_vous
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 415);
            this.Controls.Add(this.panel1);
            this.Name = "rendez_vous";
            this.Text = "rendez_vous";
            this.panel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private Bunifu.Framework.UI.BunifuDatepicker bunifuDatepicker3;
        private Bunifu.Framework.UI.BunifuDatepicker bunifuDatepicker4;
        private Bunifu.Framework.UI.BunifuDatepicker bunifuDatepicker2;
        private Bunifu.Framework.UI.BunifuDatepicker bunifuDatepicker1;
        private Bunifu.Framework.UI.BunifuFlatButton notifications;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
    }
}