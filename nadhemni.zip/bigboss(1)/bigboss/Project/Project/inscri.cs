﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class inscri : Form
    {
        public static String s;
      
            public inscri()
        {
            InitializeComponent();
            s = bunifuTextbox1.text;
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            
            

           login user = (from u in yourself.d.login
                         where u.username.Equals(bunifuTextbox1.text)&&u.mdp.Equals(bunifuTextbox2.text)
                         select u).FirstOrDefault();
            
            if(user!=null)
            { 
                
              
              s = bunifuTextbox1.text;
                Form1 r = new Form1();
                r.Show();
                
               
               

            }
            else
            { MessageBox.Show("vous devez être inscri");
            }


        }

        private void bunifuThinButton26_Click(object sender, EventArgs e)
        {
            dashbord r = new dashbord();
            r.Show();
        }

        private void bunifuGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void inscri_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
