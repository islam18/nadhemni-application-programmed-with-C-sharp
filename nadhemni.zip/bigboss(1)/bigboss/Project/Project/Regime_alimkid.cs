﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Regime_alimkid : Form
    {
        public Regime_alimkid()
        {
            InitializeComponent();
        }

        private void metroComboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {
            suivi_regime1 r = new suivi_regime1();
            r.id_regime1 = yourself.ch;
            
            r.personne = textBox1.Text;

            r.aliment_interdit = metroComboBox3.SelectedItem.ToString();
            r.aliment_apprécis = metroComboBox3.SelectedItem.ToString();
            yourself.d.suivi_regime1.InsertOnSubmit(r);



            // Submit the change to the database.
            try
            {
                yourself.d.SubmitChanges();
                MessageBox.Show(" ajouté avec succes");
                this.Close();

            }
            catch (Exception y)
            {
                Console.WriteLine(y);
            }
        }

        private void Regime_alimkid_Load(object sender, EventArgs e)
        {

        }
    }
}

