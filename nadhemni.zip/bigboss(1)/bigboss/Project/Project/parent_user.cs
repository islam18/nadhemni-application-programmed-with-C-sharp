﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class parent_user : Form
    {
        public parent_user()
        {
            InitializeComponent();
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton6_Click(object sender, EventArgs e)
        {
            regime r = new regime();
            r.Show();
        }

        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {

        }

        private void parent_user_Load(object sender, EventArgs e)
        {
            parent f = (from u in yourself.d.parents
                         where u.id_parent
                         .Equals(inscri.s)
                         select u).FirstOrDefault();
            suivi_medicament s= (from u in yourself.d.suivi_medicaments
                                 where u.id_maladie
                                 .Equals(inscri.s)
                                 select u).FirstOrDefault();
            suivi_medicament2 s2 = (from u in yourself.d.suivi_medicament2s
                                  where u.id_maladie2
                                  .Equals(inscri.s)
                                  select u).FirstOrDefault();
            suivi_rdv s1= (from u in yourself.d.suivi_rdv
                          where u.id_rdv
                          .Equals(inscri.s)
                          select u).FirstOrDefault();


           
                if(f!=null)
                { bunifuMetroTextbox1.Text = f.Etat.ToString();
                    bunifuMetroTextbox4.Text = f.Etat.ToString();
                if (s1 != null)
                {
                    bunifuDatepicker1.Value = s1.rdv_mere.Value;

                    bunifuDatepicker2.Value = s1.rdv_pere.Value;
                }
                if(s!=null)
                { bunifuMetroTextbox3.Text = s.rangement.ToString();
                    bunifuMetroTextbox6.Text = s.nom.ToString();
                   
                    if (s.nbre_de_fois == 1)
                        checkBox1.Checked = true;
                    if (s.nbre_de_fois == 2)
                    {
                        checkBox1.Checked = true;
                        checkBox2.Checked = true;
                    }
                    if (s.nbre_de_fois == 3)
                    {
                        checkBox1.Checked = true;
                        checkBox2.Checked = true;
                        checkBox3.Checked = true;

                    }
                    if (s.pension == 1)

                        checkBox6.Checked = true;
                    if (s.pension == 2)
                    {

                        checkBox5.Checked = true;
                        checkBox6.Checked = true;
                    }
                    if (s.pension == 3)
                    {
                        checkBox4.Checked = true;
                        checkBox5.Checked = true;
                        checkBox6.Checked = true;
                    }
                }
                if (s2 != null)
                {
                    bunifuMetroTextbox3.Text = s2.rangement.ToString();
                    bunifuMetroTextbox9.Text = s2.nom.ToString();

                    if (s2.nbre_de_fois == 1)
                        checkBox21.Checked = true;
                    if (s2.nbre_de_fois == 2)
                    {
                        checkBox20.Checked = true;
                        checkBox21.Checked = true;
                    }
                    if (s2.nbre_de_fois == 3)
                    {
                        checkBox19.Checked = true;
                        checkBox20.Checked = true;
                        checkBox21.Checked = true;

                    }
                    if (s2.pension == 1)

                        checkBox29.Checked = true;
                    if (s2.pension == 2)
                    {

                        checkBox29.Checked = true;
                        checkBox30.Checked = true;
                    }
                    if (s2.pension == 3)
                    {
                        checkBox28.Checked = true;
                        checkBox29.Checked = true;
                        checkBox30.Checked = true;
                    }
                }


                }

            






        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuCustomLabel1_Click(object sender, EventArgs e)
        {

        }
    }
}
