﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Medocs1 : Form
    {
        public Medocs1()
        {
            InitializeComponent();
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            suivi_medicament1 s = new suivi_medicament1();
            s.id_maladie1 = yourself.ch;
            s.rangement = metroComboBox1.SelectedItem.ToString();
            s.nom = bunifuTextbox1.text;
            
            s.nbre_de_fois = int.Parse(checkedListBox2.SelectedItem.ToString());
            yourself.d.suivi_medicament1.InsertOnSubmit(s);



            // Submit the change to the database.
            try
            {
                

                yourself.d.SubmitChanges();
                MessageBox.Show(" ajouté avec succes");
                this.Close();


            }
            catch (Exception y)
            {
                Console.WriteLine(y);
                // Make some adjustments.
                // ...
                // Try again.

            }
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
