﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Medocs : MetroFramework.Forms.MetroForm
    {
        public Medocs()
        {
            InitializeComponent();
        }

        private void Medocs_Load(object sender, EventArgs e)
        {
           
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void metroCheckBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            if (metroComboBox2.Text.Equals("père"))

            {
                suivi_medicament s = new suivi_medicament();
                s.id_maladie = yourself.ch;
                s.rangement = metroComboBox1.SelectedItem.ToString();
                s.nom = bunifuTextbox1.text;
                s.pension = int.Parse(checkedListBox2.SelectedItem.ToString());
                yourself.d.suivi_medicaments.InsertOnSubmit(s);
            }
            else
            {
                suivi_medicament2 s2 = new suivi_medicament2();
                s2.id_maladie2 = yourself.ch;
                s2.rangement = metroComboBox1.SelectedItem.ToString();
                s2.nom = bunifuTextbox1.text;
                s2.pension = int.Parse(checkedListBox2.SelectedItem.ToString());
                yourself.d.suivi_medicament2s.InsertOnSubmit(s2);
            }


            // Submit the change to the database.
            try
            {
               yourself.d.SubmitChanges();
               
                    yourself.d.SubmitChanges();
                    MessageBox.Show(" ajouté avec succes");
                this.Close();
               

            }
            catch (Exception y)
            {
                Console.WriteLine(y);
                // Make some adjustments.
                // ...
                // Try again.

            }



        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox6_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void metroCheckBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void metroComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void metroLabel3_Click(object sender, EventArgs e)
        {

        }

        private void metroTile3_Click(object sender, EventArgs e)
        {

        }

        private void checkedListBox6_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkedListBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkedListBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkedListBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void metroTile1_Click(object sender, EventArgs e)
        {

        }

        private void metroTile2_Click(object sender, EventArgs e)
        {

        }

        private void metroTile5_Click(object sender, EventArgs e)
        {

        }

        private void checkedListBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void metroTile4_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void bunifuTextbox3_OnTextChange(object sender, EventArgs e)
        {

        }

        private void bunifuTextbox2_OnTextChange(object sender, EventArgs e)
        {

        }

        private void bunifuTextbox1_OnTextChange(object sender, EventArgs e)
        {

        }
    }
}
