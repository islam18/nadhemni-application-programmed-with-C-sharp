﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using Bunifu.Framework.UI;
using System.Data.Linq;

namespace Project
{

    public partial class yourself : Form
    {
       public static String ch;
        internal static DataClasses1DataContext d = new DataClasses1DataContext();


        public yourself()
        {
            InitializeComponent();
            ch= txt_email.Text;
        }

        private void bunifuThinButton26_Click(object sender, EventArgs e)
        {
           users s = new users();
            ch= txt_email.Text; 
            s.nom = txt_nom.Text;
            s.prenom = txt_prenom.Text;
            s.email = txt_email.Text;
            s.mdp = txt_mdp.Text;
            s.fonction = txt_fonction.Text;
            s.telephone = txt_tel.Text;
            s.adresse = txt_adresse.Text;
            s.date_de_naissance = date.Value;
            login l = new login();
            l.username= txt_email.Text;
            l.mdp= txt_mdp.Text;
            //s.photo = Binary(image);
            yourself.d.users.InsertOnSubmit(s);
            
            yourself.d.login.InsertOnSubmit(l);
           


            // Submit the change to the database.
            try
            {
                d.SubmitChanges();
                MessageBox.Show("User ajouté avec succés");
                inscri m = new inscri();
                this.Close();
                m.Show();
            }
            catch (Exception y)
            {
                Console.WriteLine(y);
                // Make some adjustments.
                // ...
                // Try again.
               
            }








        }

        private void bunifuGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
