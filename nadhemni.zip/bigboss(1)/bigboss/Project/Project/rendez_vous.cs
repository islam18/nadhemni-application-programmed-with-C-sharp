﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class rendez_vous : Form
    {
        public rendez_vous()
        {
            InitializeComponent();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            suivi_rdv v = new suivi_rdv();
            v.id_rdv = yourself.ch;
            v.rdv_mere = bunifuDatepicker1.Value;
            v.rdv_pere = bunifuDatepicker4.Value;


            yourself.d.suivi_rdv.InsertOnSubmit(v);
            try
            {
                yourself.d.SubmitChanges();
                MessageBox.Show(" ajouté avec succes");
                this.Close();

            }
            catch (Exception y)
            {
                Console.WriteLine(y);
            }

        }
    }
}
