﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class user_facture : Form
    {
        public user_facture(string value)
        {
            InitializeComponent();
            t1.Text = value;
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {

        }

        private void txt_dep_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuMetroTextbox3_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void user_facture_Load(object sender, EventArgs e)
        {
            facture f = (from u in yourself.d.facture
                          where u.id_facture.Equals(inscri.s) 
                          select u).FirstOrDefault();
            DateTime p = new DateTime(2020, 5, 30);
            DateTime p1 = f.date_eau.Value;
            DateTime p2 = f.date_steg.Value;
            DateTime p3 = f.date_tel.Value;
            if (f != null)
            {
                int x = DateTime.Compare(p1, p);
                if (x == -1)
                {
                    date_eau.Value = f.date_eau.Value;
                    eau.Text = f.eau.ToString();
                    TimeSpan diff = p - p1;
                    bunifuMetroTextbox1.Text = "il vous reste" + diff.Days.ToString();

                    // MessageBox.Show("il vous reste" + f.tel.ToString());
                }
                else
                {
                    if (x == 1)
                        eau1.Text = f.eau.ToString();
                    else

                        MessageBox.Show("il faut payer aujourdhui la facture d'eau" + f.eau.ToString());
                }
                int x1 = DateTime.Compare(f.date_steg.Value, p);
                if (x1 == -1)
                {
                    TimeSpan diff1 = p - f.date_steg.Value;
                    bunifuMetroTextbox2.Text = "il vous reste" + diff1.Days.ToString();
                    date_steg.Value = f.date_steg.Value;
                    steg.Text = f.steg.ToString();
                }
                else
                {
                    if (x == 1)
                        steg1.Text = f.steg.ToString();
                    else
                        MessageBox.Show("il faut payer aujourdhui la facture du STEG" + f.steg.ToString());

                }
                int x2 = DateTime.Compare(f.date_tel.Value, p);
                if (x2 == -1)
                {
                    TimeSpan diff2 = p - f.date_tel.Value;
                    bunifuMetroTextbox3.Text = "il vous reste" + diff2.Days.ToString();
                    tel.Text = f.tel.ToString();



                    date_tel.Value = f.date_tel.Value;
                }
                else
                {
                    if (x == 1)
                        tel.Text = f.tel.ToString();

                    else
                        MessageBox.Show("il faut payer aujourdhui la facture du telephone" + f.tel.ToString());
                }

            }
            else
                MessageBox.Show("pas de factures");

        }

        private void eau1_OnValueChanged(object sender, EventArgs e)
        {

        }
    }
}
