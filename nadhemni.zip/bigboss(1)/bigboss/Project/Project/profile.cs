﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class profile : Form
    {
        public profile()
        {
            InitializeComponent();
        }

        private void bunifuMetroTextbox3_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void profile_Load(object sender, EventArgs e)
        {
         users  user = (from u in yourself.d.users
                          where u.email.Equals(inscri.s) 
                          select u).FirstOrDefault();
            if(user!=null)
            {
                bunifuDatepicker2.Value = user.date_de_naissance;


                txt_nom.Text = user.nom;
                txt_prenom.Text = user.prenom;
                txt_fonction.Text = user.fonction;
                txt_adr.Text = user.adresse;
                txt_email.Text = user.email;
                txt_tel.Text = user.telephone;
            }

        }

        private void txt_nom_OnValueChanged(object sender, EventArgs e)
        {

        }
    }
}
