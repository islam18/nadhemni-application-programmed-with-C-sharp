﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class work : Form
    {
        public work()
        {
            InitializeComponent();
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void bunifuCheckbox11_OnChange(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
           try
            {
               
                travail t = new travail();
                t.id_travail = yourself.ch;
                t.début = bunifuDatepicker1.Value;
                t.fin = bunifuDatepicker2.Value;
                //t.reunion = ;
                yourself.d.travail.InsertOnSubmit(t);
                yourself.d.SubmitChanges();
                MessageBox.Show("Le travail a ete ajouté avec succes");
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }
    }
}
