﻿namespace Project
{
    partial class Les_Factures
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Les_Factures));
            this.metroToolTip1 = new MetroFramework.Components.MetroToolTip();
            this.metroTextBox3 = new MetroFramework.Controls.MetroTextBox();
            this.metroTile4 = new MetroFramework.Controls.MetroTile();
            this.metroTextBox2 = new MetroFramework.Controls.MetroTextBox();
            this.metroTile3 = new MetroFramework.Controls.MetroTile();
            this.metroTile2 = new MetroFramework.Controls.MetroTile();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.metroTile1 = new MetroFramework.Controls.MetroTile();
            this.metroTextBox4 = new MetroFramework.Controls.MetroTextBox();
            this.metroTile5 = new MetroFramework.Controls.MetroTile();
            this.metroTextBox5 = new MetroFramework.Controls.MetroTextBox();
            this.metroTile6 = new MetroFramework.Controls.MetroTile();
            this.txt_limite = new MetroFramework.Controls.MetroDateTime();
            this.metroTile7 = new MetroFramework.Controls.MetroTile();
            this.metroTextBox6 = new MetroFramework.Controls.MetroTextBox();
            this.metroTile8 = new MetroFramework.Controls.MetroTile();
            this.metroTextBox7 = new MetroFramework.Controls.MetroTextBox();
            this.metroTile9 = new MetroFramework.Controls.MetroTile();
            this.metroTextBox8 = new MetroFramework.Controls.MetroTextBox();
            this.metroTile10 = new MetroFramework.Controls.MetroTile();
            this.metroTile11 = new MetroFramework.Controls.MetroTile();
            this.metroTextBox9 = new MetroFramework.Controls.MetroTextBox();
            this.metroTile12 = new MetroFramework.Controls.MetroTile();
            this.metroTextBox10 = new MetroFramework.Controls.MetroTextBox();
            this.metroTile13 = new MetroFramework.Controls.MetroTile();
            this.metroTextBox11 = new MetroFramework.Controls.MetroTextBox();
            this.metroTile14 = new MetroFramework.Controls.MetroTile();
            this.depense = new MetroFramework.Controls.MetroTile();
            this.metroTextBox12 = new MetroFramework.Controls.MetroTextBox();
            this.metroTile16 = new MetroFramework.Controls.MetroTile();
            this.metroTile17 = new MetroFramework.Controls.MetroTile();
            this.metroTile18 = new MetroFramework.Controls.MetroTile();
            this.metroTile19 = new MetroFramework.Controls.MetroTile();
            this.metroTile20 = new MetroFramework.Controls.MetroTile();
            this.metroTile21 = new MetroFramework.Controls.MetroTile();
            this.metroTile22 = new MetroFramework.Controls.MetroTile();
            this.metroTile23 = new MetroFramework.Controls.MetroTile();
            this.metroTile24 = new MetroFramework.Controls.MetroTile();
            this.metroTile25 = new MetroFramework.Controls.MetroTile();
            this.metroTile26 = new MetroFramework.Controls.MetroTile();
            this.metroTile27 = new MetroFramework.Controls.MetroTile();
            this.metroTile28 = new MetroFramework.Controls.MetroTile();
            this.bunifuFlatButton6 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton4 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.metroTextBox13 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox14 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox15 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox16 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox17 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox18 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox19 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox20 = new MetroFramework.Controls.MetroTextBox();
            this.txt_steg = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txt_tel = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txt_eau = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.txt_limite2 = new MetroFramework.Controls.MetroDateTime();
            this.txt_limite1 = new MetroFramework.Controls.MetroDateTime();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // metroToolTip1
            // 
            this.metroToolTip1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroToolTip1.StyleManager = null;
            this.metroToolTip1.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // metroTextBox3
            // 
            this.metroTextBox3.Lines = new string[0];
            this.metroTextBox3.Location = new System.Drawing.Point(225, 257);
            this.metroTextBox3.MaxLength = 32767;
            this.metroTextBox3.Name = "metroTextBox3";
            this.metroTextBox3.PasswordChar = '\0';
            this.metroTextBox3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox3.SelectedText = "";
            this.metroTextBox3.Size = new System.Drawing.Size(120, 30);
            this.metroTextBox3.TabIndex = 7;
            this.metroTextBox3.UseSelectable = true;
            // 
            // metroTile4
            // 
            this.metroTile4.ActiveControl = null;
            this.metroTile4.Location = new System.Drawing.Point(23, 248);
            this.metroTile4.Name = "metroTile4";
            this.metroTile4.Size = new System.Drawing.Size(143, 39);
            this.metroTile4.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile4.TabIndex = 6;
            this.metroTile4.Text = "Sécurité/Maladies";
            this.metroTile4.UseSelectable = true;
            // 
            // metroTextBox2
            // 
            this.metroTextBox2.Lines = new string[0];
            this.metroTextBox2.Location = new System.Drawing.Point(225, 168);
            this.metroTextBox2.MaxLength = 32767;
            this.metroTextBox2.Name = "metroTextBox2";
            this.metroTextBox2.PasswordChar = '\0';
            this.metroTextBox2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox2.SelectedText = "";
            this.metroTextBox2.Size = new System.Drawing.Size(120, 37);
            this.metroTextBox2.TabIndex = 5;
            this.metroTextBox2.UseSelectable = true;
            // 
            // metroTile3
            // 
            this.metroTile3.ActiveControl = null;
            this.metroTile3.Location = new System.Drawing.Point(23, 168);
            this.metroTile3.Name = "metroTile3";
            this.metroTile3.Size = new System.Drawing.Size(143, 45);
            this.metroTile3.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile3.TabIndex = 4;
            this.metroTile3.Text = "Loisirs";
            this.metroTile3.UseSelectable = true;
            // 
            // metroTile2
            // 
            this.metroTile2.ActiveControl = null;
            this.metroTile2.Location = new System.Drawing.Point(23, 340);
            this.metroTile2.Name = "metroTile2";
            this.metroTile2.Size = new System.Drawing.Size(144, 44);
            this.metroTile2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile2.TabIndex = 2;
            this.metroTile2.Text = "Date limite";
            this.metroTile2.UseSelectable = true;
            // 
            // metroTextBox1
            // 
            this.metroTextBox1.Lines = new string[0];
            this.metroTextBox1.Location = new System.Drawing.Point(224, 75);
            this.metroTextBox1.MaxLength = 32767;
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.PasswordChar = '\0';
            this.metroTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox1.SelectedText = "";
            this.metroTextBox1.Size = new System.Drawing.Size(121, 39);
            this.metroTextBox1.TabIndex = 1;
            this.metroTextBox1.UseSelectable = true;
            // 
            // metroTile1
            // 
            this.metroTile1.ActiveControl = null;
            this.metroTile1.Location = new System.Drawing.Point(23, 75);
            this.metroTile1.Name = "metroTile1";
            this.metroTile1.Size = new System.Drawing.Size(144, 47);
            this.metroTile1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile1.TabIndex = 0;
            this.metroTile1.Text = "Depenses Reguliéres";
            this.metroTile1.UseSelectable = true;
            // 
            // metroTextBox4
            // 
            this.metroTextBox4.Lines = new string[0];
            this.metroTextBox4.Location = new System.Drawing.Point(225, 257);
            this.metroTextBox4.MaxLength = 32767;
            this.metroTextBox4.Name = "metroTextBox3";
            this.metroTextBox4.PasswordChar = '\0';
            this.metroTextBox4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox4.SelectedText = "";
            this.metroTextBox4.Size = new System.Drawing.Size(120, 30);
            this.metroTextBox4.TabIndex = 7;
            this.metroTextBox4.UseSelectable = true;
            // 
            // metroTile5
            // 
            this.metroTile5.ActiveControl = null;
            this.metroTile5.Location = new System.Drawing.Point(23, 248);
            this.metroTile5.Name = "metroTile4";
            this.metroTile5.Size = new System.Drawing.Size(143, 39);
            this.metroTile5.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile5.TabIndex = 6;
            this.metroTile5.Text = "Sécurité/Maladies";
            this.metroTile5.UseSelectable = true;
            // 
            // metroTextBox5
            // 
            this.metroTextBox5.Lines = new string[0];
            this.metroTextBox5.Location = new System.Drawing.Point(225, 168);
            this.metroTextBox5.MaxLength = 32767;
            this.metroTextBox5.Name = "metroTextBox2";
            this.metroTextBox5.PasswordChar = '\0';
            this.metroTextBox5.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox5.SelectedText = "";
            this.metroTextBox5.Size = new System.Drawing.Size(120, 37);
            this.metroTextBox5.TabIndex = 5;
            this.metroTextBox5.UseSelectable = true;
            // 
            // metroTile6
            // 
            this.metroTile6.ActiveControl = null;
            this.metroTile6.Location = new System.Drawing.Point(23, 168);
            this.metroTile6.Name = "metroTile3";
            this.metroTile6.Size = new System.Drawing.Size(143, 45);
            this.metroTile6.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile6.TabIndex = 4;
            this.metroTile6.Text = "Loisirs";
            this.metroTile6.UseSelectable = true;
            // 
            // txt_limite
            // 
            this.txt_limite.Location = new System.Drawing.Point(473, 92);
            this.txt_limite.MinimumSize = new System.Drawing.Size(0, 29);
            this.txt_limite.Name = "txt_limite";
            this.txt_limite.Size = new System.Drawing.Size(209, 29);
            this.txt_limite.TabIndex = 15;
            // 
            // metroTile7
            // 
            this.metroTile7.ActiveControl = null;
            this.metroTile7.Location = new System.Drawing.Point(23, 340);
            this.metroTile7.Name = "metroTile2";
            this.metroTile7.Size = new System.Drawing.Size(144, 44);
            this.metroTile7.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile7.TabIndex = 2;
            this.metroTile7.Text = "Date limite";
            this.metroTile7.UseSelectable = true;
            // 
            // metroTextBox6
            // 
            this.metroTextBox6.Lines = new string[0];
            this.metroTextBox6.Location = new System.Drawing.Point(224, 75);
            this.metroTextBox6.MaxLength = 32767;
            this.metroTextBox6.Name = "metroTextBox1";
            this.metroTextBox6.PasswordChar = '\0';
            this.metroTextBox6.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox6.SelectedText = "";
            this.metroTextBox6.Size = new System.Drawing.Size(121, 39);
            this.metroTextBox6.TabIndex = 1;
            this.metroTextBox6.UseSelectable = true;
            // 
            // metroTile8
            // 
            this.metroTile8.ActiveControl = null;
            this.metroTile8.Location = new System.Drawing.Point(23, 75);
            this.metroTile8.Name = "metroTile1";
            this.metroTile8.Size = new System.Drawing.Size(144, 47);
            this.metroTile8.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile8.TabIndex = 0;
            this.metroTile8.Text = "Depenses Reguliéres";
            this.metroTile8.UseSelectable = true;
            // 
            // metroTextBox7
            // 
            this.metroTextBox7.Lines = new string[0];
            this.metroTextBox7.Location = new System.Drawing.Point(225, 257);
            this.metroTextBox7.MaxLength = 32767;
            this.metroTextBox7.Name = "metroTextBox3";
            this.metroTextBox7.PasswordChar = '\0';
            this.metroTextBox7.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox7.SelectedText = "";
            this.metroTextBox7.Size = new System.Drawing.Size(120, 30);
            this.metroTextBox7.TabIndex = 7;
            this.metroTextBox7.UseSelectable = true;
            // 
            // metroTile9
            // 
            this.metroTile9.ActiveControl = null;
            this.metroTile9.Location = new System.Drawing.Point(23, 248);
            this.metroTile9.Name = "metroTile4";
            this.metroTile9.Size = new System.Drawing.Size(143, 39);
            this.metroTile9.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile9.TabIndex = 6;
            this.metroTile9.Text = "Sécurité/Maladies";
            this.metroTile9.UseSelectable = true;
            // 
            // metroTextBox8
            // 
            this.metroTextBox8.Lines = new string[0];
            this.metroTextBox8.Location = new System.Drawing.Point(225, 168);
            this.metroTextBox8.MaxLength = 32767;
            this.metroTextBox8.Name = "metroTextBox2";
            this.metroTextBox8.PasswordChar = '\0';
            this.metroTextBox8.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox8.SelectedText = "";
            this.metroTextBox8.Size = new System.Drawing.Size(120, 37);
            this.metroTextBox8.TabIndex = 5;
            this.metroTextBox8.UseSelectable = true;
            // 
            // metroTile10
            // 
            this.metroTile10.ActiveControl = null;
            this.metroTile10.Location = new System.Drawing.Point(23, 168);
            this.metroTile10.Name = "metroTile3";
            this.metroTile10.Size = new System.Drawing.Size(143, 45);
            this.metroTile10.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile10.TabIndex = 4;
            this.metroTile10.Text = "Loisirs";
            this.metroTile10.UseSelectable = true;
            // 
            // metroTile11
            // 
            this.metroTile11.ActiveControl = null;
            this.metroTile11.Location = new System.Drawing.Point(23, 340);
            this.metroTile11.Name = "metroTile2";
            this.metroTile11.Size = new System.Drawing.Size(144, 44);
            this.metroTile11.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile11.TabIndex = 2;
            this.metroTile11.Text = "Date limite";
            this.metroTile11.UseSelectable = true;
            // 
            // metroTextBox9
            // 
            this.metroTextBox9.Lines = new string[0];
            this.metroTextBox9.Location = new System.Drawing.Point(224, 75);
            this.metroTextBox9.MaxLength = 32767;
            this.metroTextBox9.Name = "metroTextBox1";
            this.metroTextBox9.PasswordChar = '\0';
            this.metroTextBox9.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox9.SelectedText = "";
            this.metroTextBox9.Size = new System.Drawing.Size(121, 39);
            this.metroTextBox9.TabIndex = 1;
            this.metroTextBox9.UseSelectable = true;
            // 
            // metroTile12
            // 
            this.metroTile12.ActiveControl = null;
            this.metroTile12.Location = new System.Drawing.Point(23, 75);
            this.metroTile12.Name = "metroTile1";
            this.metroTile12.Size = new System.Drawing.Size(144, 47);
            this.metroTile12.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile12.TabIndex = 0;
            this.metroTile12.Text = "Depenses Reguliéres";
            this.metroTile12.UseSelectable = true;
            // 
            // metroTextBox10
            // 
            this.metroTextBox10.Lines = new string[0];
            this.metroTextBox10.Location = new System.Drawing.Point(225, 257);
            this.metroTextBox10.MaxLength = 32767;
            this.metroTextBox10.Name = "metroTextBox3";
            this.metroTextBox10.PasswordChar = '\0';
            this.metroTextBox10.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox10.SelectedText = "";
            this.metroTextBox10.Size = new System.Drawing.Size(120, 30);
            this.metroTextBox10.TabIndex = 7;
            this.metroTextBox10.UseSelectable = true;
            // 
            // metroTile13
            // 
            this.metroTile13.ActiveControl = null;
            this.metroTile13.Location = new System.Drawing.Point(23, 248);
            this.metroTile13.Name = "metroTile4";
            this.metroTile13.Size = new System.Drawing.Size(143, 39);
            this.metroTile13.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile13.TabIndex = 6;
            this.metroTile13.Text = "Sécurité/Maladies";
            this.metroTile13.UseSelectable = true;
            // 
            // metroTextBox11
            // 
            this.metroTextBox11.Lines = new string[0];
            this.metroTextBox11.Location = new System.Drawing.Point(225, 168);
            this.metroTextBox11.MaxLength = 32767;
            this.metroTextBox11.Name = "metroTextBox2";
            this.metroTextBox11.PasswordChar = '\0';
            this.metroTextBox11.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox11.SelectedText = "";
            this.metroTextBox11.Size = new System.Drawing.Size(120, 37);
            this.metroTextBox11.TabIndex = 5;
            this.metroTextBox11.UseSelectable = true;
            // 
            // metroTile14
            // 
            this.metroTile14.ActiveControl = null;
            this.metroTile14.Location = new System.Drawing.Point(23, 168);
            this.metroTile14.Name = "metroTile3";
            this.metroTile14.Size = new System.Drawing.Size(143, 45);
            this.metroTile14.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile14.TabIndex = 4;
            this.metroTile14.Text = "Loisirs";
            this.metroTile14.UseSelectable = true;
            // 
            // depense
            // 
            this.depense.ActiveControl = null;
            this.depense.Location = new System.Drawing.Point(23, 340);
            this.depense.Name = "metroTile2";
            this.depense.Size = new System.Drawing.Size(144, 44);
            this.depense.Style = MetroFramework.MetroColorStyle.Red;
            this.depense.TabIndex = 2;
            this.depense.Text = "Date limite";
            this.depense.UseSelectable = true;
            // 
            // metroTextBox12
            // 
            this.metroTextBox12.Lines = new string[0];
            this.metroTextBox12.Location = new System.Drawing.Point(224, 75);
            this.metroTextBox12.MaxLength = 32767;
            this.metroTextBox12.Name = "metroTextBox1";
            this.metroTextBox12.PasswordChar = '\0';
            this.metroTextBox12.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox12.SelectedText = "";
            this.metroTextBox12.Size = new System.Drawing.Size(121, 39);
            this.metroTextBox12.TabIndex = 1;
            this.metroTextBox12.UseSelectable = true;
            // 
            // metroTile16
            // 
            this.metroTile16.ActiveControl = null;
            this.metroTile16.Location = new System.Drawing.Point(23, 75);
            this.metroTile16.Name = "metroTile1";
            this.metroTile16.Size = new System.Drawing.Size(144, 47);
            this.metroTile16.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile16.TabIndex = 0;
            this.metroTile16.Text = "Depenses Reguliéres";
            this.metroTile16.UseSelectable = true;
            // 
            // metroTile17
            // 
            this.metroTile17.ActiveControl = null;
            this.metroTile17.Location = new System.Drawing.Point(23, 248);
            this.metroTile17.Name = "metroTile4";
            this.metroTile17.Size = new System.Drawing.Size(143, 39);
            this.metroTile17.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile17.TabIndex = 6;
            this.metroTile17.Text = "Sécurité/Maladies";
            this.metroTile17.UseSelectable = true;
            // 
            // metroTile18
            // 
            this.metroTile18.ActiveControl = null;
            this.metroTile18.Location = new System.Drawing.Point(23, 168);
            this.metroTile18.Name = "metroTile3";
            this.metroTile18.Size = new System.Drawing.Size(143, 45);
            this.metroTile18.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile18.TabIndex = 4;
            this.metroTile18.Text = "Loisirs";
            this.metroTile18.UseSelectable = true;
            // 
            // metroTile19
            // 
            this.metroTile19.ActiveControl = null;
            this.metroTile19.Location = new System.Drawing.Point(23, 340);
            this.metroTile19.Name = "metroTile2";
            this.metroTile19.Size = new System.Drawing.Size(144, 44);
            this.metroTile19.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile19.TabIndex = 2;
            this.metroTile19.Text = "Date limite";
            this.metroTile19.UseSelectable = true;
            // 
            // metroTile20
            // 
            this.metroTile20.ActiveControl = null;
            this.metroTile20.Location = new System.Drawing.Point(23, 75);
            this.metroTile20.Name = "metroTile1";
            this.metroTile20.Size = new System.Drawing.Size(144, 47);
            this.metroTile20.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile20.TabIndex = 0;
            this.metroTile20.Text = "Depenses Reguliéres";
            this.metroTile20.UseSelectable = true;
            // 
            // metroTile21
            // 
            this.metroTile21.ActiveControl = null;
            this.metroTile21.Location = new System.Drawing.Point(23, 248);
            this.metroTile21.Name = "metroTile4";
            this.metroTile21.Size = new System.Drawing.Size(143, 39);
            this.metroTile21.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile21.TabIndex = 6;
            this.metroTile21.Text = "Sécurité/Maladies";
            this.metroTile21.UseSelectable = true;
            // 
            // metroTile22
            // 
            this.metroTile22.ActiveControl = null;
            this.metroTile22.Location = new System.Drawing.Point(23, 168);
            this.metroTile22.Name = "metroTile3";
            this.metroTile22.Size = new System.Drawing.Size(143, 45);
            this.metroTile22.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile22.TabIndex = 4;
            this.metroTile22.Text = "Loisirs";
            this.metroTile22.UseSelectable = true;
            // 
            // metroTile23
            // 
            this.metroTile23.ActiveControl = null;
            this.metroTile23.Location = new System.Drawing.Point(23, 340);
            this.metroTile23.Name = "metroTile2";
            this.metroTile23.Size = new System.Drawing.Size(144, 44);
            this.metroTile23.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile23.TabIndex = 2;
            this.metroTile23.Text = "Date limite";
            this.metroTile23.UseSelectable = true;
            // 
            // metroTile24
            // 
            this.metroTile24.ActiveControl = null;
            this.metroTile24.Location = new System.Drawing.Point(23, 75);
            this.metroTile24.Name = "metroTile1";
            this.metroTile24.Size = new System.Drawing.Size(144, 47);
            this.metroTile24.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile24.TabIndex = 0;
            this.metroTile24.Text = "Depenses Reguliéres";
            this.metroTile24.UseSelectable = true;
            // 
            // metroTile25
            // 
            this.metroTile25.ActiveControl = null;
            this.metroTile25.Location = new System.Drawing.Point(23, 248);
            this.metroTile25.Name = "metroTile4";
            this.metroTile25.Size = new System.Drawing.Size(143, 39);
            this.metroTile25.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile25.TabIndex = 6;
            this.metroTile25.Text = "Sécurité/Maladies";
            this.metroTile25.UseSelectable = true;
            // 
            // metroTile26
            // 
            this.metroTile26.ActiveControl = null;
            this.metroTile26.Location = new System.Drawing.Point(23, 168);
            this.metroTile26.Name = "metroTile3";
            this.metroTile26.Size = new System.Drawing.Size(143, 45);
            this.metroTile26.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile26.TabIndex = 4;
            this.metroTile26.Text = "Loisirs";
            this.metroTile26.UseSelectable = true;
            // 
            // metroTile27
            // 
            this.metroTile27.ActiveControl = null;
            this.metroTile27.Location = new System.Drawing.Point(23, 340);
            this.metroTile27.Name = "metroTile2";
            this.metroTile27.Size = new System.Drawing.Size(144, 44);
            this.metroTile27.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile27.TabIndex = 2;
            this.metroTile27.Text = "Date limite";
            this.metroTile27.UseSelectable = true;
            // 
            // metroTile28
            // 
            this.metroTile28.ActiveControl = null;
            this.metroTile28.Location = new System.Drawing.Point(23, 75);
            this.metroTile28.Name = "metroTile1";
            this.metroTile28.Size = new System.Drawing.Size(144, 47);
            this.metroTile28.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile28.TabIndex = 0;
            this.metroTile28.Text = "Depenses Reguliéres";
            this.metroTile28.UseSelectable = true;
            // 
            // bunifuFlatButton6
            // 
            this.bunifuFlatButton6.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton6.BorderRadius = 7;
            this.bunifuFlatButton6.ButtonText = "Eau";
            this.bunifuFlatButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton6.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton6.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton6.Iconimage = null;
            this.bunifuFlatButton6.Iconimage_right = null;
            this.bunifuFlatButton6.Iconimage_right_Selected = null;
            this.bunifuFlatButton6.Iconimage_Selected = null;
            this.bunifuFlatButton6.IconMarginLeft = 0;
            this.bunifuFlatButton6.IconMarginRight = 0;
            this.bunifuFlatButton6.IconRightVisible = true;
            this.bunifuFlatButton6.IconRightZoom = 0D;
            this.bunifuFlatButton6.IconVisible = true;
            this.bunifuFlatButton6.IconZoom = 90D;
            this.bunifuFlatButton6.IsTab = false;
            this.bunifuFlatButton6.Location = new System.Drawing.Point(12, 92);
            this.bunifuFlatButton6.Name = "bunifuFlatButton6";
            this.bunifuFlatButton6.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton6.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton6.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton6.selected = false;
            this.bunifuFlatButton6.Size = new System.Drawing.Size(187, 38);
            this.bunifuFlatButton6.TabIndex = 35;
            this.bunifuFlatButton6.Text = "Eau";
            this.bunifuFlatButton6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton6.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton6.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton3
            // 
            this.bunifuFlatButton3.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton3.BorderRadius = 7;
            this.bunifuFlatButton3.ButtonText = "Telephone/Internet";
            this.bunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton3.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.Iconimage = null;
            this.bunifuFlatButton3.Iconimage_right = null;
            this.bunifuFlatButton3.Iconimage_right_Selected = null;
            this.bunifuFlatButton3.Iconimage_Selected = null;
            this.bunifuFlatButton3.IconMarginLeft = 0;
            this.bunifuFlatButton3.IconMarginRight = 0;
            this.bunifuFlatButton3.IconRightVisible = true;
            this.bunifuFlatButton3.IconRightZoom = 0D;
            this.bunifuFlatButton3.IconVisible = true;
            this.bunifuFlatButton3.IconZoom = 90D;
            this.bunifuFlatButton3.IsTab = false;
            this.bunifuFlatButton3.Location = new System.Drawing.Point(12, 232);
            this.bunifuFlatButton3.Name = "bunifuFlatButton3";
            this.bunifuFlatButton3.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton3.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton3.selected = false;
            this.bunifuFlatButton3.Size = new System.Drawing.Size(187, 38);
            this.bunifuFlatButton3.TabIndex = 37;
            this.bunifuFlatButton3.Text = "Telephone/Internet";
            this.bunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton3.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton3.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton4
            // 
            this.bunifuFlatButton4.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton4.BorderRadius = 7;
            this.bunifuFlatButton4.ButtonText = "STEG";
            this.bunifuFlatButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton4.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton4.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton4.Iconimage = null;
            this.bunifuFlatButton4.Iconimage_right = null;
            this.bunifuFlatButton4.Iconimage_right_Selected = null;
            this.bunifuFlatButton4.Iconimage_Selected = null;
            this.bunifuFlatButton4.IconMarginLeft = 0;
            this.bunifuFlatButton4.IconMarginRight = 0;
            this.bunifuFlatButton4.IconRightVisible = true;
            this.bunifuFlatButton4.IconRightZoom = 0D;
            this.bunifuFlatButton4.IconVisible = true;
            this.bunifuFlatButton4.IconZoom = 90D;
            this.bunifuFlatButton4.IsTab = false;
            this.bunifuFlatButton4.Location = new System.Drawing.Point(12, 159);
            this.bunifuFlatButton4.Name = "bunifuFlatButton4";
            this.bunifuFlatButton4.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton4.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton4.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton4.selected = false;
            this.bunifuFlatButton4.Size = new System.Drawing.Size(187, 38);
            this.bunifuFlatButton4.TabIndex = 38;
            this.bunifuFlatButton4.Text = "STEG";
            this.bunifuFlatButton4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton4.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton4.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // metroTextBox13
            // 
            this.metroTextBox13.Lines = new string[0];
            this.metroTextBox13.Location = new System.Drawing.Point(225, 257);
            this.metroTextBox13.MaxLength = 32767;
            this.metroTextBox13.Name = "metroTextBox3";
            this.metroTextBox13.PasswordChar = '\0';
            this.metroTextBox13.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox13.SelectedText = "";
            this.metroTextBox13.Size = new System.Drawing.Size(120, 30);
            this.metroTextBox13.TabIndex = 7;
            this.metroTextBox13.UseSelectable = true;
            // 
            // metroTextBox14
            // 
            this.metroTextBox14.Lines = new string[0];
            this.metroTextBox14.Location = new System.Drawing.Point(0, 0);
            this.metroTextBox14.MaxLength = 32767;
            this.metroTextBox14.Name = "metroTextBox14";
            this.metroTextBox14.PasswordChar = '\0';
            this.metroTextBox14.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox14.SelectedText = "";
            this.metroTextBox14.Size = new System.Drawing.Size(0, 22);
            this.metroTextBox14.TabIndex = 0;
            this.metroTextBox14.UseSelectable = true;
            // 
            // metroTextBox15
            // 
            this.metroTextBox15.Lines = new string[0];
            this.metroTextBox15.Location = new System.Drawing.Point(0, 0);
            this.metroTextBox15.MaxLength = 32767;
            this.metroTextBox15.Name = "metroTextBox15";
            this.metroTextBox15.PasswordChar = '\0';
            this.metroTextBox15.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox15.SelectedText = "";
            this.metroTextBox15.Size = new System.Drawing.Size(0, 22);
            this.metroTextBox15.TabIndex = 0;
            this.metroTextBox15.UseSelectable = true;
            // 
            // metroTextBox16
            // 
            this.metroTextBox16.Lines = new string[0];
            this.metroTextBox16.Location = new System.Drawing.Point(0, 0);
            this.metroTextBox16.MaxLength = 32767;
            this.metroTextBox16.Name = "metroTextBox16";
            this.metroTextBox16.PasswordChar = '\0';
            this.metroTextBox16.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox16.SelectedText = "";
            this.metroTextBox16.Size = new System.Drawing.Size(0, 22);
            this.metroTextBox16.TabIndex = 0;
            this.metroTextBox16.UseSelectable = true;
            // 
            // metroTextBox17
            // 
            this.metroTextBox17.Lines = new string[0];
            this.metroTextBox17.Location = new System.Drawing.Point(0, 0);
            this.metroTextBox17.MaxLength = 32767;
            this.metroTextBox17.Name = "metroTextBox17";
            this.metroTextBox17.PasswordChar = '\0';
            this.metroTextBox17.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox17.SelectedText = "";
            this.metroTextBox17.Size = new System.Drawing.Size(0, 22);
            this.metroTextBox17.TabIndex = 0;
            this.metroTextBox17.UseSelectable = true;
            // 
            // metroTextBox18
            // 
            this.metroTextBox18.Lines = new string[0];
            this.metroTextBox18.Location = new System.Drawing.Point(224, 75);
            this.metroTextBox18.MaxLength = 32767;
            this.metroTextBox18.Name = "metroTextBox1";
            this.metroTextBox18.PasswordChar = '\0';
            this.metroTextBox18.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox18.SelectedText = "";
            this.metroTextBox18.Size = new System.Drawing.Size(121, 39);
            this.metroTextBox18.TabIndex = 1;
            this.metroTextBox18.UseSelectable = true;
            // 
            // metroTextBox19
            // 
            this.metroTextBox19.Lines = new string[0];
            this.metroTextBox19.Location = new System.Drawing.Point(224, 75);
            this.metroTextBox19.MaxLength = 32767;
            this.metroTextBox19.Name = "metroTextBox1";
            this.metroTextBox19.PasswordChar = '\0';
            this.metroTextBox19.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox19.SelectedText = "";
            this.metroTextBox19.Size = new System.Drawing.Size(121, 39);
            this.metroTextBox19.TabIndex = 1;
            this.metroTextBox19.UseSelectable = true;
            // 
            // metroTextBox20
            // 
            this.metroTextBox20.Lines = new string[0];
            this.metroTextBox20.Location = new System.Drawing.Point(0, 0);
            this.metroTextBox20.MaxLength = 32767;
            this.metroTextBox20.Name = "metroTextBox20";
            this.metroTextBox20.PasswordChar = '\0';
            this.metroTextBox20.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox20.SelectedText = "";
            this.metroTextBox20.Size = new System.Drawing.Size(0, 22);
            this.metroTextBox20.TabIndex = 0;
            this.metroTextBox20.UseSelectable = true;
            // 
            // txt_steg
            // 
            this.txt_steg.BorderColorFocused = System.Drawing.Color.Blue;
            this.txt_steg.BorderColorIdle = System.Drawing.Color.Silver;
            this.txt_steg.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.txt_steg.BorderThickness = 3;
            this.txt_steg.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_steg.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txt_steg.ForeColor = System.Drawing.Color.Gray;
            this.txt_steg.isPassword = false;
            this.txt_steg.Location = new System.Drawing.Point(225, 160);
            this.txt_steg.Margin = new System.Windows.Forms.Padding(4);
            this.txt_steg.Name = "txt_steg";
            this.txt_steg.Size = new System.Drawing.Size(209, 37);
            this.txt_steg.TabIndex = 40;
            this.txt_steg.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txt_tel
            // 
            this.txt_tel.BorderColorFocused = System.Drawing.Color.Blue;
            this.txt_tel.BorderColorIdle = System.Drawing.Color.Silver;
            this.txt_tel.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.txt_tel.BorderThickness = 3;
            this.txt_tel.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_tel.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txt_tel.ForeColor = System.Drawing.Color.Gray;
            this.txt_tel.isPassword = false;
            this.txt_tel.Location = new System.Drawing.Point(225, 232);
            this.txt_tel.Margin = new System.Windows.Forms.Padding(4);
            this.txt_tel.Name = "txt_tel";
            this.txt_tel.Size = new System.Drawing.Size(209, 37);
            this.txt_tel.TabIndex = 41;
            this.txt_tel.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txt_eau
            // 
            this.txt_eau.BorderColorFocused = System.Drawing.Color.Blue;
            this.txt_eau.BorderColorIdle = System.Drawing.Color.Silver;
            this.txt_eau.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.txt_eau.BorderThickness = 3;
            this.txt_eau.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_eau.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txt_eau.ForeColor = System.Drawing.Color.Gray;
            this.txt_eau.isPassword = false;
            this.txt_eau.Location = new System.Drawing.Point(225, 92);
            this.txt_eau.Margin = new System.Windows.Forms.Padding(4);
            this.txt_eau.Name = "txt_eau";
            this.txt_eau.Size = new System.Drawing.Size(209, 37);
            this.txt_eau.TabIndex = 42;
            this.txt_eau.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(6, 30);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(189, 33);
            this.bunifuCustomLabel1.TabIndex = 43;
            this.bunifuCustomLabel1.Text = "Vos factures";
            this.bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(783, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(139, 83);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 7;
            this.bunifuFlatButton1.ButtonText = "Valider ";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton1.Iconimage")));
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(455, 346);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(163, 59);
            this.bunifuFlatButton1.TabIndex = 13;
            this.bunifuFlatButton1.Text = "Valider ";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // txt_limite2
            // 
            this.txt_limite2.Location = new System.Drawing.Point(473, 241);
            this.txt_limite2.MinimumSize = new System.Drawing.Size(0, 29);
            this.txt_limite2.Name = "txt_limite2";
            this.txt_limite2.Size = new System.Drawing.Size(209, 29);
            this.txt_limite2.TabIndex = 44;
            // 
            // txt_limite1
            // 
            this.txt_limite1.Location = new System.Drawing.Point(473, 168);
            this.txt_limite1.MinimumSize = new System.Drawing.Size(0, 29);
            this.txt_limite1.Name = "txt_limite1";
            this.txt_limite1.Size = new System.Drawing.Size(209, 29);
            this.txt_limite1.TabIndex = 45;
            // 
            // Les_Factures
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(934, 450);
            this.Controls.Add(this.txt_limite2);
            this.Controls.Add(this.txt_limite1);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Controls.Add(this.txt_eau);
            this.Controls.Add(this.txt_tel);
            this.Controls.Add(this.txt_steg);
            this.Controls.Add(this.bunifuFlatButton4);
            this.Controls.Add(this.bunifuFlatButton3);
            this.Controls.Add(this.bunifuFlatButton6);
            this.Controls.Add(this.txt_limite);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.bunifuFlatButton1);
            this.Name = "Les_Factures";
            this.Text = "Les_Factures";
            this.Load += new System.EventHandler(this.Les_Factures_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MetroFramework.Components.MetroToolTip metroToolTip1;
        private MetroFramework.Controls.MetroTextBox metroTextBox3;
        private MetroFramework.Controls.MetroTile metroTile4;
        private MetroFramework.Controls.MetroTextBox metroTextBox2;
        private MetroFramework.Controls.MetroTile metroTile3;
        private MetroFramework.Controls.MetroTile metroTile2;
        private MetroFramework.Controls.MetroTextBox metroTextBox1;
        private MetroFramework.Controls.MetroTile metroTile1;
        private MetroFramework.Controls.MetroTextBox metroTextBox4;
        private MetroFramework.Controls.MetroTile metroTile5;
        private MetroFramework.Controls.MetroTextBox metroTextBox5;
        private MetroFramework.Controls.MetroTile metroTile6;
        private MetroFramework.Controls.MetroDateTime txt_limite;
        private MetroFramework.Controls.MetroTile metroTile7;
        private MetroFramework.Controls.MetroTextBox metroTextBox6;
        private MetroFramework.Controls.MetroTile metroTile8;
        private MetroFramework.Controls.MetroTextBox metroTextBox7;
        private MetroFramework.Controls.MetroTile metroTile9;
        private MetroFramework.Controls.MetroTextBox metroTextBox8;
        private MetroFramework.Controls.MetroTile metroTile10;
        private MetroFramework.Controls.MetroTile metroTile11;
        private MetroFramework.Controls.MetroTextBox metroTextBox9;
        private MetroFramework.Controls.MetroTile metroTile12;
        private MetroFramework.Controls.MetroTextBox metroTextBox10;
        private MetroFramework.Controls.MetroTile metroTile13;
        private MetroFramework.Controls.MetroTextBox metroTextBox11;
        private MetroFramework.Controls.MetroTile metroTile14;
        private MetroFramework.Controls.MetroTile depense;
        private MetroFramework.Controls.MetroTextBox metroTextBox12;
        private MetroFramework.Controls.MetroTile metroTile16;
        private MetroFramework.Controls.MetroTile metroTile17;
        private MetroFramework.Controls.MetroTile metroTile18;
        private MetroFramework.Controls.MetroTile metroTile19;
        private MetroFramework.Controls.MetroTile metroTile20;
        private MetroFramework.Controls.MetroTile metroTile21;
        private MetroFramework.Controls.MetroTile metroTile22;
        private MetroFramework.Controls.MetroTile metroTile23;
        private MetroFramework.Controls.MetroTile metroTile24;
        private MetroFramework.Controls.MetroTile metroTile25;
        private MetroFramework.Controls.MetroTile metroTile26;
        private MetroFramework.Controls.MetroTile metroTile27;
        private MetroFramework.Controls.MetroTile metroTile28;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton6;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton3;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton4;
        private MetroFramework.Controls.MetroTextBox metroTextBox13;
        private MetroFramework.Controls.MetroTextBox metroTextBox14;
        private MetroFramework.Controls.MetroTextBox metroTextBox15;
        private MetroFramework.Controls.MetroTextBox metroTextBox16;
        private MetroFramework.Controls.MetroTextBox metroTextBox17;
        private MetroFramework.Controls.MetroTextBox metroTextBox18;
        private MetroFramework.Controls.MetroTextBox metroTextBox19;
        private MetroFramework.Controls.MetroTextBox metroTextBox20;
        private Bunifu.Framework.UI.BunifuMetroTextbox txt_steg;
        private Bunifu.Framework.UI.BunifuMetroTextbox txt_tel;
        private Bunifu.Framework.UI.BunifuMetroTextbox txt_eau;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private MetroFramework.Controls.MetroDateTime txt_limite2;
        private MetroFramework.Controls.MetroDateTime txt_limite1;
    }
}