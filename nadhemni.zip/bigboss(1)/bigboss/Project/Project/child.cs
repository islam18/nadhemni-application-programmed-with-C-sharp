﻿using Project;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projet
{
    public partial class child : MetroFramework.Forms.MetroForm
    {
        public static String ch;
        internal static DataClasses1DataContext d = new DataClasses1DataContext();
        public child()
        {
            InitializeComponent();
        }

        private void child_Load(object sender, EventArgs e)
        {
            al.Checked=false;
            bunifuCheckbox4.Checked = false;
            bunifuCheckbox6.Checked = false;




        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            
        }

        private void bunifuCheckbox1_OnChange(object sender, EventArgs e)
        {
            rdv_vousc v = new rdv_vousc();
            v.ShowDialog();
        }

        private void bunifuCheckbox6_OnChange(object sender, EventArgs e)
        {
            Regime_alimkid r = new Regime_alimkid();
            r.ShowDialog();

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            enfant1 enf = new enfant1();
            enf.id_enfant = yourself.ch;
            enf.id_medicament_enfant = yourself.ch;
            enf.id_rdv_enfant = yourself.ch;
            enf.id_regime_enfant = yourself.ch;
           
            enf.nombre = int.Parse(v.SelectedItem.ToString());
            enf.etablissement = v1.SelectedItem.ToString();
            if (bunifuCheckbox4.Checked)
                enf.maladie = 1;
            else
                enf.maladie = 0;
            if (bunifuCheckbox6.Checked)
                enf.regime = 1;
            else
                enf.regime = 0;

            yourself.d.enfant1s.InsertOnSubmit(enf);
            try
            {
                yourself.d.SubmitChanges();
                MessageBox.Show(" ajouté avec succes");
                this.Close();

            }
            catch (Exception y)
            {
                Console.WriteLine(y);
            }

        }

        private void bunifuCheckbox4_OnChange(object sender, EventArgs e)
        {
            Medocs1 m = new Medocs1();
            m.ShowDialog();
        }

        private void v_onItemSelected(object sender, EventArgs e)
        {

        }
    }
}
