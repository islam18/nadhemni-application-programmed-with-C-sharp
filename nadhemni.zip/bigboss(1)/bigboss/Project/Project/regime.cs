﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class regime : Form
    {
        public regime()
        {
            InitializeComponent();
        }

        private void regime_Load(object sender, EventArgs e)
        {
          suivi_regime f = (from u in yourself.d.suivi_regime
                        where u.id_regime
                        .Equals(inscri.s)
                        select u).FirstOrDefault();
            suivi_regime2 f1 = (from u in yourself.d.suivi_regime2s
                              where u.id_regime2
                              .Equals(inscri.s)
                              select u).FirstOrDefault();
            if (f1 != null)
            {
                alim_mere.Text = f1.aliment_interdit.ToString();
                bunifuMetroTextbox3.Text = f1.durée.ToString();
                alim1_mere.Text = f1.aliment_apprécis.ToString();
            }
            else
                MessageBox.Show("pas de regime pour la mère");
            if (f != null)
            {
                alim1_pere.Text = f.aliment_apprécis.ToString();
                alim_pere.Text = f.aliment_interdit.ToString();
                bunifuMetroTextbox5.Text = f.durée.ToString();
            }
            else
                MessageBox.Show("pas de regime pour le père");










        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
