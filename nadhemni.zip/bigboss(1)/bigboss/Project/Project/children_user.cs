﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class children_user : Form
    {
        public children_user()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuFlatButton6_Click(object sender, EventArgs e)
        {
            Regimalimc r = new Regimalimc();
            r.Show();
        }

        private void children_user_Load(object sender, EventArgs e)
        {
            enfant1 f = (from u in yourself.d.enfant1s
                        where u.id_enfant
                        .Equals(inscri.s)
                        select u).FirstOrDefault();
            
            suivi_medicament1 s2 = (from u in yourself.d.suivi_medicament1
                                    where u.id_maladie1
                                    .Equals(inscri.s)
                                    select u).FirstOrDefault();
            suivi_rdv1 s1 = (from u in yourself.d.suivi_rdv1
                            where u.id_rdv1
                            .Equals(inscri.s)
                            select u).FirstOrDefault();

         if(f!=null)
            {if(s1!=null)
                { bunifuDatepicker1.Value = s1.controle.Value;

                    bunifuDatepicker2.Value = s1.vaccin.Value;
                    txt_dep.Text = s1.nom.ToString();
                    bunifuMetroTextbox5.Text=s1.nom.ToString();
                }

            if(s2!=null)
                { bunifuMetroTextbox6.Text = s2.nom.ToString();
                    if (s2.nbre_de_fois == 1)
                        checkBox1.Checked = true;
                    if (s2.nbre_de_fois == 2)
                    {
                        checkBox1.Checked = true;
                        checkBox2.Checked = true;
                    }
                    if (s2.nbre_de_fois == 3)
                    {
                        checkBox1.Checked = true;
                        checkBox2.Checked = true;
                        checkBox3.Checked = true;

                    }
                    if (s2.pension == 1)

                        checkBox6.Checked = true;
                    if (s2.pension == 2)
                    {

                        checkBox6.Checked = true;
                        checkBox5.Checked = true;
                    }
                    if (s2.pension == 3)
                    {
                        checkBox5.Checked = true;
                        checkBox6.Checked = true;
                        checkBox4.Checked = true;
                    }
                }

            }
        }
    }
}
