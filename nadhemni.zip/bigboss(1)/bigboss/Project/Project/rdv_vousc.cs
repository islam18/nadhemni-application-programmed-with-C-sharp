﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class rdv_vousc : Form
    {
        public rdv_vousc()
        {
            InitializeComponent();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            suivi_rdv1 v = new suivi_rdv1();
            v.id_rdv1 = yourself.ch;
            v.nom = textBox1.Text ;
            v.controle = bunifuDatepicker1.Value;
            v.vaccin = bunifuDatepicker4.Value;
            yourself.d.suivi_rdv1.InsertOnSubmit(v);
            try
            {
                yourself.d.SubmitChanges();
                MessageBox.Show(" ajouté avec succes");
                this.Close();

            }
            catch (Exception y)
            {
                Console.WriteLine(y);
            }

        }
    }
}
