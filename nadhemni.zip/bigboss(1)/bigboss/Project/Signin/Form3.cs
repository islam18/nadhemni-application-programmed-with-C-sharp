﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Signin
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void bunifuGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {   
            
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            sign f = new sign();
            f.ShowDialog();

        }

        private void bunifuThinButton26_Click(object sender, EventArgs e)
        {
            sign f = new sign();
            f.ShowDialog();

        }
    }
}
